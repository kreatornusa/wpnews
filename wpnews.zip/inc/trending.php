<?php 
add_shortcode( 'trending', 'trending_shortcode' );
function trending_shortcode( $atts ) {
	global $post;
	$rentang = $atts["rentang"];
	$paged = ( get_query_var('paged') ) ? get_query_var('paged') : 1;
		$argstrending = array(
			'post_type' => 'post',
			'meta_key' => 'post_views_count',
			'orderby'   => 'meta_value_num',
			'post_status' => 'publish',
            'paged' => $paged,
			'order' => 'DESC',
			'date_query' => array(
				array(
					'after' => $rentang,
				),
			)
		);
	$konten = "";
	$my_trending = new WP_Query( $argstrending );
	if ( $my_trending->have_posts() ):
		$konten .= '<div class="terkini-box">';
		while ( $my_trending->have_posts() ) {
			$my_trending->the_post();
			$konten .= '
		            <div class="terkini-item">
		              <div class="terkini-image media-image">
		                  ' . customthumbnail($post->ID, "image_188_113"). '
		              </div>
		              <div class="terkini-content">
		                <div class="terkini-meta">
		                  <div class="terkini-category"><a href="' . linkcategory(). '">' . labelcategory(). '</a></div>
		                  <div class="terkini-date">' . timeago(). '</div>
		                </div>
		                <div class="terkini-title">
		                  <h2><a class="terkini-link media-link" href="' . get_permalink(). '">' . get_the_title(). '</a></h2>
		                </div>
		              </div>
		            </div>';
		}
		$konten .= '</div>';
        if($my_trending->max_num_pages > 1):
        	$konten .= '
              <div class="widget-pagination">
                <div class="paging-box">';
            $big = 999999999; // need an unlikely integer
             
            $konten .= paginate_links( array(
                'base'    => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
                'format'  => '?paged=%#%',
                'current' => max( 1, get_query_var('paged') ),
                'total'   => $my_trending->max_num_pages,
						    'next_text' => '<span class="icon icon-angle-right"></span>',
						    'prev_text' => '<span class="icon icon-angle-left"></span>',
            ) );

            $konten .= '</div>
          </div>';
      endif;
	endif;
	wp_reset_postdata();
	return $konten;
}
?>