<main class="main">
  <div class="container">
    <div class="row">
      <div class="col-8">

     <div class="widget terkini">
        <div class="widget-header">
          <h3 class="title"><?php the_title(); ?></h3>
        </div>

          <div class="filter">
            <div class="filter-tanggal">
              <span>Pilih Tanggal</span>
              <div id="reportrange">
                <span id="daterange"></span>
                <i class="icon icon-caret-down"></i>
              </div>
            </div>
          </div>

          <?php
          global $post;
          $url = $_GET['daterange'];
          $exp = explode(' - ',$url);
          $timestart = strtotime($exp[0]. ' - 1 days');
          $timeend = strtotime($exp[1]. ' + 1 days');
          $start = date('Y-m-d',$timestart);
          $end = date('Y-m-d',$timeend);
          $paged = ( get_query_var( 'paged' ) ) ? get_query_var( 'paged' ) : 1;
          if(isset($_GET['daterange'])):
          $args = array(
          'post_type' => 'post',
          'post_status' => 'publish',
          'paged' => $paged,
          'date_query' => array(
                array(
                  'after'     => $start,
                  'before'    => $end,
                ),
            ),
          );
          else:
          $args = array(
          'post_type' => 'post',
          'paged' => $paged,
          'post_status' => 'publish',
          );
          endif;
          ?>
        <div class="widget-content">
          <div class="terkini-box">

          <?php
          $my_query = new WP_Query( $args );
          if ( $my_query->have_posts() ): ?>
            <?php
            while ( $my_query->have_posts() ) {
              $my_query->the_post();
              ?>
            <div class="terkini-item">
              <div class="terkini-image media-image">
                  <?php echo customthumbnail($post->ID, "image_188_113"); ?>
              </div>
              <div class="terkini-content">
                <div class="terkini-meta">
                  <div class="terkini-category"><a href="<?php echo linkcategory(); ?>"><?php echo labelcategory(); ?></a></div>
                  <div class="terkini-date"><?php echo timeago(); ?></div>
                </div>
                <div class="terkini-title">
                  <h2><a class="terkini-link media-link" href="<?php echo get_permalink(); ?>"><?php echo get_the_title(); ?></a></h2>
                </div>
              </div>
            </div>
                <?php
                }
                wp_reset_postdata();
                ?>
            <?php endif; ?>


          </div>
              <?php 
              if($my_query->max_num_pages > 1):
               ?>
              <div class="widget-pagination">
                <div class="paging-box">
                    <?php
                  $big = 999999999; // need an unlikely integer
                   
                  echo paginate_links( array(
                      'base'    => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
                      'format'  => '?paged=%#%',
                      'current' => max( 1, get_query_var('paged') ),
                      'total'   => $my_query->max_num_pages,
                      'next_text' => '<span class="icon icon-angle-right"></span>',
                      'prev_text' => '<span class="icon icon-angle-left"></span>',
                  ) );
                  ?>
                </div>
              </div>
            <?php endif; ?>
        </div>
       </div>




      </div>
      <aside class="col-4">
      <?php 
      if (is_active_sidebar('sidebar_area')) :
        dynamic_sidebar('sidebar_area');
      endif;
      ?>
      </aside>
    </div>
  </div>
</main>


