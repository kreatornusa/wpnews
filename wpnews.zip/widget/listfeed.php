<?php
function listfeedViewDesktop($title,$category,$feed,$jml){
	if(!empty($category) && $category!="-1" ):
	$response = wp_remote_get( $feed . 'posts/?categories=' . $category . '&per_page=' . $jml .'&status=publish&type=post' );
	else:
	$response = wp_remote_get( $feed . 'posts/?per_page=' . $jml.'&status=publish&type=post' );
	endif;
	$posts = json_decode( wp_remote_retrieve_body( $response ) );

	if ( is_array( $response ) && ! is_wp_error( $response ) ) {
	   if( !empty( $posts ) ) { 
	   	?>
     <div class="widget list">
        <?php if(!empty($title)): ?>
	     	<div class="widget-header">
	     		<h3 class="title"><?php echo $title; ?></h3>
	     	</div>
	      <?php endif; ?>
	     	<div class="widget-content">
					<?php foreach( $posts as $post ) {?>
            <div class="list-item">
              <div class="list-hastag">#</div>
              <div class="list-content">
                  <h2 class="list-title">
                  	<a href="<?php echo $post->link ?>" class="list-link media-link" target="_blank">
                  		<?php echo $post->title->rendered; ?>
                  	</a>
                  </h2>
                
              </div>
            </div>
					<?php } ?>
	     	</div>
	     </div>
	      <?php
	   }
	}
}
function listfeedViewMobile($title,$category,$feed,$jml){
	if(!empty($category) && $category!="-1" ):
	$response = wp_remote_get( $feed . 'posts/?categories=' . $category . '&per_page=' . $jml .'&status=publish&type=post' );
	else:
	$response = wp_remote_get( $feed . 'posts/?per_page=' . $jml.'&status=publish&type=post' );
	endif;
	$posts = json_decode( wp_remote_retrieve_body( $response ) );

	if ( is_array( $response ) && ! is_wp_error( $response ) ) {
	   if( !empty( $posts ) ) { 
	   	?>
     <div class="widget list">
        <?php if(!empty($title)): ?>
	     	<div class="widget-header">
	     		<h3 class="title"><?php echo $title; ?></h3>
	     	</div>
	      <?php endif; ?>
	     	<div class="widget-content">
					<?php foreach( $posts as $post ) {?>
            <div class="list-item">
              <div class="list-hastag">#</div>
              <div class="list-content">
                  <h2 class="list-title">
                  	<a href="<?php echo $post->link ?>" class="list-link media-link" target="_blank">
                  		<?php echo $post->title->rendered; ?>
                  	</a>
                  </h2>
                
              </div>
            </div>
					<?php } ?>
	     	</div>
	     </div>
	      <?php
	   }
	}
}
class listfeedWidget extends WP_Widget {

	public function __construct() {
		$idwidget = 'listfeed';
		$namewidget = '📌 Feed Network Sidebar';
		$descwidget = 'Daftar post yang diambil dari media newtwork dan ditampilkan dalam bentuk list di Sidebar.';
		parent::__construct($idwidget, $namewidget, array('description'=> $descwidget));
	}
	public function widget( $args, $instance ) {
		if($instance['mobile'] == 'yes'){
			if (function_exists( 'is_amp_endpoint' ) && is_amp_endpoint()) {
				listfeedViewMobile($instance['title'], $instance['category'], $instance['urlfeed'], $instance['amountmobile']);
			}elseif (wp_is_mobile()) {
				listfeedViewMobile($instance['title'], $instance['category'], $instance['urlfeed'], $instance['amountmobile']);
			}
		}
		if($instance['desktop'] == 'yes'){
			if (function_exists( 'is_amp_endpoint' ) && is_amp_endpoint()) {
			}elseif (wp_is_mobile()) {
			}else{
				listfeedViewDesktop($instance['title'], $instance['category'], $instance['urlfeed'], $instance['amountdesktop']);
			}
		}
	}
	public function update( $new_instance, $old_instance ) {
		$instance = array();
		if ( ! empty( $new_instance['title'] ) ) {
			$instance['title'] = sanitize_text_field( $new_instance['title'] );
		}
		if ( ! empty( $new_instance['urlfeed'] ) ) {
			$instance['urlfeed'] = sanitize_text_field( $new_instance['urlfeed'] );
		}
		if ( ! empty( $new_instance['category'] ) ) {
			$instance['category'] = sanitize_text_field( $new_instance['category'] );
		}
		if ( ! empty( $new_instance['amountdesktop'] ) ) {
			$instance['amountdesktop'] = sanitize_text_field( $new_instance['amountdesktop'] );
		}
		if ( ! empty( $new_instance['amountmobile'] ) ) {
			$instance['amountmobile'] = sanitize_text_field( $new_instance['amountmobile'] );
		}
		$instance['desktop'] = isset( $new_instance['desktop'] ) ? 'yes' : 'no';
		$instance['mobile'] = isset( $new_instance['mobile'] ) ? 'yes' : 'no';
		return $instance;
	}
	public function form( $instance ) {
		$defaults = array(
			'title' => '',
			'urlfeed' => '/wp-json/wp/v2/',
			'category' => '-1',
			'amountdesktop' => '3',
			'amountmobile' => '3',
			'desktop' => 'yes',
			'mobile' => 'yes',
		);
		$instance = wp_parse_args( (array) $instance, $defaults ); 
		?>
		<div class="related-form-controls">
			<p>
				<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:' ); ?></label>
				<input type="text" class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" value="<?php echo $instance['title']; ?>" />
			</p>
			<hr>

			<h3>Pengaturan Feed</h3>
			<p>
				<label for="<?php echo $this->get_field_id( 'urlfeed' ); ?>">URL Api Network</label>
				<input type="text" class="widefat" id="<?php echo $this->get_field_id( 'urlfeed' ); ?>" name="<?php echo $this->get_field_name( 'urlfeed' ); ?>" value="<?php echo $instance['urlfeed']; ?>" />
			</p>
			<p>
				<label for="<?php echo $this->get_field_id( 'category' ); ?>"><?php echo 'Masukan ID kategori:'; ?></label>
				<input type="number" class="widefat" id="<?php echo $this->get_field_id( 'category' ); ?>" name="<?php echo $this->get_field_name( 'category' ); ?>" value="<?php echo $instance['category']; ?>" required/>
			</p>
			<hr>
			<h3>Pengaturan Widget</h3>
			<p>
				<label for="<?php echo $this->get_field_id( 'amountdesktop' ); ?>"><?php echo 'Jumlah pos di desktop:'; ?></label>
				<input type="number" class="widefat" id="<?php echo $this->get_field_id( 'amountdesktop' ); ?>" name="<?php echo $this->get_field_name( 'amountdesktop' ); ?>" min="1" max="10" value="<?php echo $instance['amountdesktop']; ?>" required/>
			</p>
			<p>
				<label for="<?php echo $this->get_field_id( 'amountmobile' ); ?>"><?php echo 'Jumlah pos di mobile:'; ?></label>
				<input type="number" class="widefat" id="<?php echo $this->get_field_id( 'amountmobile' ); ?>" name="<?php echo $this->get_field_name( 'amountmobile' ); ?>" min="1" max="10" value="<?php echo $instance['amountmobile']; ?>" required/>
			</p>
			<hr>
			<h3>Pengaturan Tampilan</h3>
			<p>
				<input type="checkbox" id="<?php echo $this->get_field_id( 'desktop' ); ?>" name="<?php echo $this->get_field_name( 'desktop' ); ?>" value="yes"<?php checked( 'yes', $instance['desktop'] ); ?>>
				<label for="<?php echo $this->get_field_id( 'desktop' ); ?>">Tampilkan dalam versi desktop</label><br>

				<input type="checkbox" id="<?php echo $this->get_field_id( 'mobile' ); ?>" name="<?php echo $this->get_field_name( 'mobile' ); ?>" value="yes"<?php checked( 'yes', $instance['mobile'] ); ?>>
				<label for="<?php echo $this->get_field_id( 'mobile' ); ?>">Tampilkan dalam versi mobile</label>
			</p>
		</div>
		<?php
	}
}

function listfeedWidgetload() {
	register_widget( 'listfeedWidget' );
}
add_action( 'widgets_init', 'listfeedWidgetload' );