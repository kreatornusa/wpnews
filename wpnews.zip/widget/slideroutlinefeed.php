<?php
function slideroutlinefeedViewDesktop($title,$nama,$url,$feed,$category,$jml){
	if(!empty($category) && $category!="-1" ):
	$response = wp_remote_get( $feed . 'posts/?categories=' . $category . '&per_page=' . $jml .'&status=publish&type=post' );
	else:
	$response = wp_remote_get( $feed . 'posts/?per_page=' . $jml.'&status=publish&type=post' );
	endif;

	$posts = json_decode( wp_remote_retrieve_body($response));
	if (is_array($response) && ! is_wp_error($response )) {
	   if(!empty($posts)){ 
	   	?>
	     <div class="widget slider1 slider-bg">
	        <?php if(!empty($title)): ?>
		     	<div class="widget-header">
		     		<h3 class="title"><?php echo $title; ?></h3>
		     	</div>
		      <?php endif; ?>
		     	<div class="widget-content">
		     		<div class="slider1-box">
			    	<?php foreach( $posts as $post ) {
			    	$t = strtotime($post->date);
						if ( ! empty( $post->featured_media ) ) {
						  $thumb_id = $post->featured_media;
						  $responsethumb = wp_remote_get( $feed . 'media/' . $thumb_id );
						  $thumb = json_decode( wp_remote_retrieve_body( $responsethumb ) );

						}?>
		     			<div class="slider1-item col-4">
		     				<div class="slider1-image media-image">
		     					<?php if($thumb->media_details->sizes->image_230_136->source_url != ""): ?>
	      			 			<img src="<?php echo $thumb->media_details->sizes->image_230_136->source_url; ?>" alt="<?php echo $post->title->rendered; ?>" />
	      			 		<?php endif; ?>
		     				</div>
		     				<div class="slider1-content">
		     					<div class="slider1-title">
		     						<h2><a class="slider1-link media-link" href="<?php echo $post->link ?>" target="_blank"><?php echo $post->title->rendered; ?></a></h2>
		     					</div>
		     				</div>
	     					<div class="slider1-more"><?php echo $nama; ?>
	     					</div>
		     			</div>
						<?php
						}
				      ?>
		     		</div>
		     	</div>
	     </div>
	      <?php
	   }
	}

}
function slideroutlinefeedViewMobile($title,$nama,$url,$feed,$category,$jml){
	if(!empty($category) && $category!="-1" ):
	$response = wp_remote_get( $feed . 'posts/?categories=' . $category . '&per_page=' . $jml .'&status=publish&type=post' );
	else:
	$response = wp_remote_get( $feed . 'posts/?per_page=' . $jml.'&status=publish&type=post' );
	endif;

	$posts = json_decode( wp_remote_retrieve_body($response));
	if (is_array($response) && ! is_wp_error($response )) {
	   if(!empty($posts)){ 
	   	?>
	     <div class="widget slider1 slider-bg">
	        <?php if(!empty($title)): ?>
		     	<div class="widget-header">
		     		<h3 class="title"><?php echo $title; ?></h3>
		     	</div>
		      <?php endif; ?>
		     	<div class="widget-content">
		     		<div class="slider1-box">
			    	<?php foreach( $posts as $post ) {
			    	$t = strtotime($post->date);
						if ( ! empty( $post->featured_media ) ) {
						  $thumb_id = $post->featured_media;
						  $responsethumb = wp_remote_get( $feed . 'media/' . $thumb_id );
						  $thumb = json_decode( wp_remote_retrieve_body( $responsethumb ) );

						}?>
		     			<div class="slider1-item col-3">
		     				<div class="slider1-image media-image">
		     					<?php if($thumb->media_details->sizes->image_230_136->source_url != ""): ?>
	      			 			<img src="<?php echo $thumb->media_details->sizes->image_230_136->source_url; ?>" alt="<?php echo $post->title->rendered; ?>" />
	      			 		<?php endif; ?>
		     				</div>
		     				<div class="slider1-content">
		     					<div class="slider1-title">
		     						<h2><a class="slider1-link media-link" href="<?php echo $post->link ?>" target="_blank"><?php echo $post->title->rendered; ?></a></h2>
		     					</div>
		     				</div>
	     					<div class="slider1-more"><?php echo $nama; ?>
	     					</div>
		     			</div>
						<?php
						}
				      ?>
		     		</div>
		     	</div>
	     </div>
	      <?php
	   }
	}

}
class slideroutlinefeed extends WP_Widget {

	public function __construct() {
		$idwidget = 'slideroutlinefeed';
		$namewidget = '📌 Slider Media Network';
		$descwidget = 'Slider yang ditampilkan berdasarkan artikel dari database network yang dipilih dan ditampilkan dalam bentuk grid';
		parent::__construct($idwidget, $namewidget, array('description'=> $descwidget));
	}
	public function widget( $args, $instance ) {
		if($instance['mobile'] == 'yes'){
			if (function_exists( 'is_amp_endpoint' ) && is_amp_endpoint()) {
				slideroutlinefeedViewMobile($instance['title'],$instance['nama'], $instance['url'],$instance['urlfeed'], $instance['category'], $instance['amountmobile']);
			}elseif (wp_is_mobile()) {
				slideroutlinefeedViewMobile($instance['title'],$instance['nama'], $instance['url'],$instance['urlfeed'], $instance['category'], $instance['amountmobile']);
			}
		}
		if($instance['desktop'] == 'yes'){
			if (function_exists( 'is_amp_endpoint' ) && is_amp_endpoint()) {
			}elseif (wp_is_mobile()) {
			}else{
				slideroutlinefeedViewDesktop($instance['title'],$instance['nama'], $instance['url'],$instance['urlfeed'], $instance['category'], $instance['amountdesktop']);
			}
		}
	}
	public function update( $new_instance, $old_instance ) {
		$instance = array();
		if ( ! empty( $new_instance['title'] ) ) {
			$instance['title'] = sanitize_text_field( $new_instance['title'] );
		}
		if ( ! empty( $new_instance['nama'] ) ) {
			$instance['nama'] = sanitize_text_field( $new_instance['nama'] );
		}
		if ( ! empty( $new_instance['url'] ) ) {
			$instance['url'] = sanitize_text_field( $new_instance['url'] );
		}
		if ( ! empty( $new_instance['urlfeed'] ) ) {
			$instance['urlfeed'] = sanitize_text_field( $new_instance['urlfeed'] );
		}
		if ( ! empty( $new_instance['category'] ) ) {
			$instance['category'] = sanitize_text_field( $new_instance['category'] );
		}
		if ( ! empty( $new_instance['amountdesktop'] ) ) {
			$instance['amountdesktop'] = sanitize_text_field( $new_instance['amountdesktop'] );
		}
		if ( ! empty( $new_instance['amountmobile'] ) ) {
			$instance['amountmobile'] = sanitize_text_field( $new_instance['amountmobile'] );
		}
		$instance['desktop'] = isset( $new_instance['desktop'] ) ? 'yes' : 'no';
		$instance['mobile'] = isset( $new_instance['mobile'] ) ? 'yes' : 'no';
		return $instance;
	}

	public function form( $instance ) {
		$defaults = array(
			'title' => '',
			'nama' => '',
			'url' => '',
			'urlfeed' => '/wp-json/wp/v2/',
			'category' => '-1',
			'amountdesktop' => '3',
			'amountmobile' => '3',
			'desktop' => 'yes',
			'mobile' => 'yes',
		);
		$instance = wp_parse_args( (array) $instance, $defaults ); 
		?>
		<div class="related-form-controls">
			<p>
				<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:' ); ?></label>
				<input type="text" class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" value="<?php echo $instance['title']; ?>" />
			</p>
			<hr>
			<h3>Pengaturan Network</h3>
			<p>
				<label for="<?php echo $this->get_field_id( 'nama' ); ?>">Nama Network</label>
				<input type="text" class="widefat" id="<?php echo $this->get_field_id( 'nama' ); ?>" name="<?php echo $this->get_field_name( 'nama' ); ?>" value="<?php echo $instance['nama']; ?>" />
			</p>
			<p>
				<label for="<?php echo $this->get_field_id( 'url' ); ?>">URL Network</label>
				<input type="text" class="widefat" id="<?php echo $this->get_field_id( 'url' ); ?>" name="<?php echo $this->get_field_name( 'url' ); ?>" value="<?php echo $instance['url']; ?>" />
			</p>
			<h3>Pengaturan Feed</h3>
			<p>
				<label for="<?php echo $this->get_field_id( 'urlfeed' ); ?>">URL Api Network</label>
				<input type="text" class="widefat" id="<?php echo $this->get_field_id( 'urlfeed' ); ?>" name="<?php echo $this->get_field_name( 'urlfeed' ); ?>" value="<?php echo $instance['urlfeed']; ?>" />
			</p>
			<p>
				<label for="<?php echo $this->get_field_id( 'category' ); ?>"><?php echo 'Masukan ID kategori:'; ?></label>
				<input type="number" class="widefat" id="<?php echo $this->get_field_id( 'category' ); ?>" name="<?php echo $this->get_field_name( 'category' ); ?>" value="<?php echo $instance['category']; ?>" required/>
			</p>
			<hr>
			<p>
				<label for="<?php echo $this->get_field_id( 'amountdesktop' ); ?>"><?php echo 'Jumlah pos di desktop:'; ?></label>
				<input type="number" class="widefat" id="<?php echo $this->get_field_id( 'amountdesktop' ); ?>" name="<?php echo $this->get_field_name( 'amountdesktop' ); ?>" min="1" max="10" value="<?php echo $instance['amountdesktop']; ?>" required/>
			</p>
			<p>
				<label for="<?php echo $this->get_field_id( 'amountmobile' ); ?>"><?php echo 'Jumlah pos di mobile:'; ?></label>
				<input type="number" class="widefat" id="<?php echo $this->get_field_id( 'amountmobile' ); ?>" name="<?php echo $this->get_field_name( 'amountmobile' ); ?>" min="1" max="10" value="<?php echo $instance['amountmobile']; ?>" required/>
			</p>
			<hr>
			<h3>Pengaturan Tampilan</h3>
			<p>
				<input type="checkbox" id="<?php echo $this->get_field_id( 'desktop' ); ?>" name="<?php echo $this->get_field_name( 'desktop' ); ?>" value="yes"<?php checked( 'yes', $instance['desktop'] ); ?>>
				<label for="<?php echo $this->get_field_id( 'desktop' ); ?>">Tampilkan dalam versi desktop</label><br>

				<input type="checkbox" id="<?php echo $this->get_field_id( 'mobile' ); ?>" name="<?php echo $this->get_field_name( 'mobile' ); ?>" value="yes"<?php checked( 'yes', $instance['mobile'] ); ?>>
				<label for="<?php echo $this->get_field_id( 'mobile' ); ?>">Tampilkan dalam versi mobile</label>
			</p>
		</div>
		<?php
	}
}

function slideroutlinefeedload() {
	register_widget( 'slideroutlinefeed' );
}
add_action( 'widgets_init', 'slideroutlinefeedload' ); 
?>