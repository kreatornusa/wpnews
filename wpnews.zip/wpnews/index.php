<?php get_header(); ?>
<?php if(!empty(get_theme_mod( 'layout' ))):
if(get_theme_mod( 'layout' ) == "layoutbox"):
?>
<div class="content boxed">
<?php
else:
?>
<div class="content">
<?php
endif;
?>
<?php else: ?>
<div class="content">
<?php endif; ?>
<?php get_template_part("template-parts/header/index"); ?>
<?php get_template_part("template-parts/custom/billboard-ads"); ?>
<?php get_template_part("template-parts/home/index"); ?>
<?php get_template_part("template-parts/footer/index"); ?>
</div>
<?php get_template_part("template-parts/custom/sticky-ads"); ?>
<?php get_footer(); ?>