<main class="main">
    <div class="container">
            <?php 
            if (is_active_sidebar('tophomepage_area')) :
                dynamic_sidebar('tophomepage_area');
            endif;
            ?>
            <aside>
            <?php 
            if (is_active_sidebar('sidebar_area')) :
                dynamic_sidebar('sidebar_area');
            endif;
            ?>
            </aside>
    </div>
</main>