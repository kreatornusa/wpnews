<?php $info = get_post_meta(get_the_ID(), "info", true); ?>
<main class="main">
	<div class="container">
		<div class="row">
			<div class="col-12">
		    <div class="breadcrumb">
		      <ul class="breadcrumb-wrap">
		        <li class="breadcrumb-item">
		          <a class="breadcrumb-link" href="<?php echo home_url(); ?>">
		            <i class="icons-home"></i>
		          </a>
		        </li>
		        <li class="breadcrumb-item">
				  <a class="breadcrumb-link" href="<?php echo linkcategory(); ?>"><?php echo labelcategory(); ?></a>
		        </li>
		      </ul>
		    </div>

				<?php 
				if (have_posts()):
				while (have_posts()): the_post();
				?>

		    <div class="post-header">
		    	<div class="post-title">
		      	<h1><?php the_title(); ?></h1>
		    	</div>
		    	<div class="post-subheader">
		    	<div class="post-meta">
		    		<div class="post-meta-author">
		    		<a href="<?php echo get_author_posts_url(get_the_author_meta("ID")); ?>"><?php echo get_the_author(); ?></a> 
		    		</div>
		    		<div class="post-meta-date"> - <?php echo get_the_date(get_option("date_format")); ?> | <?php echo get_the_time(get_option("time_format")); ?> WIB
		    		</div>
		    	</div>
		    	<div class="post-share">
				        <div class="social-item">
				          <a href="https://web.facebook.com/sharer/sharer.php?u=<?php echo get_the_permalink(); ?>" target="_blank" rel="nofollow" class="social-link facebook">
				            <span class="icon icon-facebook"></span>
				          </a>
				        </div>
				        <div class="social-item">
				          <a href="https://twitter.com/intent/tweet?text=<?php echo get_the_permalink(); ?>" target="_blank" rel="nofollow" class="social-link twitter">
				            <span class="icon icon-twitter"></span>
				          </a>
				        </div>
				        <div class="social-item">
				          <a href="https://api.whatsapp.com/send/?text=<?php echo get_the_title(); ?> | <?php echo get_the_permalink(); ?>" target="_blank" rel="nofollow" class="social-link whatsapp">
				            <span class="icon icon-whatsapp"></span>
				          </a>
				        </div>
				        <div class="social-item">
				          <a href="https://t.me/share/url?url=<?php echo get_the_permalink(); ?>&text=<?php echo get_the_title(); ?>" target="_blank" rel="nofollow" class="social-link telegram">
				            <span class="icon-telegram"></span>
				          </a>
				        </div>
		    	</div>
		    	</div>
		    </div>
		    <div class="post-featured">
		      <?php if (has_post_thumbnail(get_the_ID())): ?>
			      <figure class="featured-image">
			        <a data-fslightbox="gallery"  href="<?php echo get_the_post_thumbnail_url($post_id,'full'); ?>">
								<?php echo get_the_post_thumbnail($post_id, "full");?>
		    			</a>
					    <?php
					    $caption = get_post(get_post_thumbnail_id())->post_excerpt;
					    ?>
						<?php if (!empty($caption)) { ?>
								<figcaption><?php echo $caption; ?></figcaption>
						<?php } ?>
			    </figure>
				<?php endif; ?>
		    </div>
		    <div class="post-content">
				<?php the_content(); ?>
		    </div>
				<?php
				  global $page, $pages;
				  if (count($pages) > 1): ?>
			      <div class="post-pagination">
			        <div class="post-pagination-box">
			          <div class="post-pagination-label">Halaman: </div>
			          <div class="post-pagination-number">
									<?php
							     wp_link_pages("before=&after=");
							     if ($page == count($pages)):
							         wp_link_pages(
							             'before=<div class="pagination-nextprev">&after=</div>&nextpagelink=&next_or_number=next&previouspagelink=<span class="btn-next">Sebelumnya</span>'
							         );
							     else:
							         wp_link_pages(
							             'before=<div class="pagination-nextprev">&after=</div>&nextpagelink=<span class="btn-next">Selanjutnya</span>&next_or_number=next&previouspagelink='
							         );
							     endif;
							     ?>
			        	</div>
			        </div>
			      </div>
						<?php endif;
				  ?>

				<?php
				endwhile;
				endif; ?>

		    	<div class="post-subheader bottom-share">
		    	<div class="post-meta">
		    		<div class="sumber">
							<?php if (true == get_theme_mod("sumber", true)): ?>
								<?php if (!empty($info["sumber"])): ?>
							      <p><b>Sumber :</b> <?php echo $info["sumber"]; ?></p>
								<?php endif; ?>
						    <?php endif; ?>
							<?php if (true == get_theme_mod("editor", true)): ?>
								<?php if (!empty($info["editor"]) && $info["editor"] != "-1"): ?>
							      <p><b>Editor :</b> <?php echo get_author_name($info["editor"]); ?></p>
								<?php endif; ?>
						    <?php endif; ?>
		    		</div>
		    	</div>
		    	<div class="post-share">
				        <div class="social-item">
				          <a href="https://web.facebook.com/sharer/sharer.php?u=<?php echo get_the_permalink(); ?>" target="_blank" rel="nofollow" class="social-link facebook">
				            <span class="icon icon-facebook"></span>
				          </a>
				        </div>
				        <div class="social-item">
				          <a href="https://twitter.com/intent/tweet?text=<?php echo get_the_permalink(); ?>" target="_blank" rel="nofollow" class="social-link twitter">
				            <span class="icon icon-twitter"></span>
				          </a>
				        </div>
				        <div class="social-item">
				          <a href="https://api.whatsapp.com/send/?text=<?php echo get_the_title(); ?> | <?php echo get_the_permalink(); ?>" target="_blank" rel="nofollow" class="social-link whatsapp">
				            <span class="icon icon-whatsapp"></span>
				          </a>
				        </div>
				        <div class="social-item">
				          <a href="https://t.me/share/url?url=<?php echo get_the_permalink(); ?>&text=<?php echo get_the_title(); ?>" target="_blank" rel="nofollow" class="social-link telegram">
				            <span class="icon-telegram"></span>
				          </a>
				        </div>
		    	</div>
		    	</div>

		      <?php if (has_tag()): ?>
		        <div class="widget post-tag">
		        	<div class="widget-header">
		          	<h3 class="title">Tag</h3>
		        	</div>
		          <div class="widget-content">
		          	<?php the_tags(
		               '<ul class="posttag-box"><li>',
		               "</li><li>",
		               "</li></ul>"
		           ); ?>
		          </div>
		        </div>
		 	 <?php endif; ?>

			<?php if (is_active_sidebar("afterpos_area")): ?>
				<div class="post-more">
		    	<?php dynamic_sidebar("afterpos_area"); ?>
				</div>
		 <?php endif; ?>
			</div>
			<aside class="col-12">
			<?php 
			if (is_active_sidebar('sidebar_area')) :
				dynamic_sidebar('sidebar_area');
			endif;
			?>
			</aside>
		</div>
	</div>
</main>