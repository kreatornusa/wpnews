<main class="main">
  <div class="container">
    <div class="row">
      <div class="col-12 error-page">

        <div class="p404 clearfix">
          <div class="display-table">
            <div class="display-center">
              <div class="p404__title">404</div>
              <img src="<?php echo get_template_directory_uri() . '/assets/images/404.png'; ?>" alt="" style="width:50%">
              <div class="p404__content">Halaman yang Anda cari tidak ditemukan.</div>
              <a href="<?php echo get_home_url(); ?>" class="p404__link">Kembali</a>
            </div>
          </div>
        </div>

      </div>
    </div>
  </div>
</div>