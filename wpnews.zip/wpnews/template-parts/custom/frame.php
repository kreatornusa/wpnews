<div class="frame">
	<div class="frame-wrapper">
		<div class="frame-box">
			<div class="frame-widget">
				<div class="frame-item menu">
					<button class="menubar bar" aria-label="Menu">
						<span></span>
						<span></span>
						<span></span>
					</button>
					<span class="menubar-title">MENU</span>
					<span class="menubar-close hide">Tutup</span>
				</div>
				<div class="frame-item sidebarmenu">
					<?php
					if (is_active_sidebar('sidebar_menu')) :
						dynamic_sidebar('sidebar_menu');
					endif;
					?>
				</div>
				<div class="frame-item search">
					<div class="frame-search">
						<form class="frame-search-form" method="get" action="<?php echo home_url('/'); ?>">
							<div class="frame-search-wrapper">
								<input  class="frame-input-search" type="text" name="s" placeholder="Cari di sini..." value="<?php the_search_query(); ?>" maxlength="50">
								<input type="hidden" name="post_type" value="post" />
								<button type="text" class="search-icon" aria-label="search"></button>
							</div>
						</form>
					</div>
				</div>
				<div class="frame-item userbutton">
					<?php
				    if ( true == get_theme_mod( 'darkmode', true )) :
						echo '<button class="mode" aria-label="darmode"><i class="icon-darkmode"></i></button>';
				    endif;
					if ( has_nav_menu( 'user_menu' ) ) : 
						user_menu();
					endif;
					?>
				</div>
				<div class="frame-inner"></div>
			</div>
		</div>
	</div>
</div>