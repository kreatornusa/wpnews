<?php 
/* 
Template Name: Custom
*/
get_header(); ?>
<div class="content">
<?php get_template_part("template-parts/header/index"); ?>
<?php get_template_part("template-parts/custom/billboard-ads"); ?>
<?php get_template_part("template-parts/trending/index"); ?>
<?php get_template_part("template-parts/footer/index"); ?>
</div>
<?php get_template_part("template-parts/custom/sticky-ads"); ?>
<?php get_footer(); ?>