<?php 
function lightboximage($content) {
    global $post;
    $pattern        = array('{<figure class="wp-block-image(.*?)"><img loading="(.*?)" width="(.*?)" height="(.*?)" src="(.*?)"(.*?) />}','{</figure>}');
    $replacement    = array('<figure class="wp-block-image$1"><a data-fslightbox="gallery" href="$5"><img loading="$2" width="$3" height="$4" src="$5"$6/></a>','</figure>');
    $content        = preg_replace($pattern,$replacement,$content);
    return $content;
 }
 add_filter('the_content','lightboximage');

function lightboxgallery($content) {
    global $post;
    $pattern        = array('{<li class="blocks-gallery-item"><figure><a href="(.*?)">}','{</a></figure></li>}');
    $replacement    = array('<li class="blocks-gallery-item"><figure><a data-fslightbox="gallery" href="$1">','</a></figure></li>');
    $content        = preg_replace($pattern,$replacement,$content);
    return $content;
 }
 add_filter('the_content','lightboxgallery');

 ?>