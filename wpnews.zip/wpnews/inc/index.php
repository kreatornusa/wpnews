<?php 
require 'setup.php';
require 'lic.php';
require 'customizer.php';
require 'emoji.php';
require 'thumbnail.php';
require 'menu-image.php';
require 'css.php';
require 'js.php';
require 'add-menu.php';
require 'section.php';
require 'brand.php';
require 'view.php';
require 'timeago.php';
require 'related.php';
require 'trending.php';
require 'comment-threads.php';
require 'custom-post.php';
require 'lightbox.php';

function themesapp_excerpt( $count ) {
$permalink = get_permalink($post->ID);
$excerpt = get_the_content();
$excerpt = strip_tags($excerpt);
$excerpt = substr($excerpt, 0, $count);
$excerpt = substr($excerpt, 0, strripos($excerpt, " "));
$excerpt = '<p>'.$excerpt.'...</p>';
return $excerpt;
}
?>