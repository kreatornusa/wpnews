<?php 
function timeago(){
	$code = get_the_date(get_option("date_format")) . ' | ' . get_the_time(get_option("time_format"));
	return $code;
}
?>