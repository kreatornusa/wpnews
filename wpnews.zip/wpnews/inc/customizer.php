<?php 

function addCustomize($wp_customize) {
	$wp_customize->add_panel( 'ThemesappPos', array(
	  'title' => 'Umum',
	  'priority' => 162,
	));


	$wp_customize->add_section( 'tipefont', array(
		'title' => 'Tipe Font',
	  	'description'=> 'Ubah font sesuai dengan selera dan keinginan anda..',
		'panel' => 'ThemesappPos',
	));

	$wp_customize->add_setting( 'font',
	 array(
	    'default'    => 'Inter, sans-serif',
	    'type'       => 'theme_mod',
	    'capability' => 'edit_theme_options',
	 ));


	$wp_customize->add_control( new WP_Customize_Control(
		 $wp_customize,
		 'theme_font',
		 array(
		    'label'      => __( 'Pilih Font' ), 
		    'settings'   => 'font',
		    'section'    => 'tipefont',
		    'type'    => 'select',
		    'choices' => array(
				"Roboto, sans-serif" => "Roboto",
				"Montserrat, sans-serif" => "Montserrat",
				"Lato, sans-serif" => "Lato",
				"'PT Sans', sans-serif" => "PT Sans",
				"Poppins, sans-serif" => "Poppins",
				"'Source Sans Pro', sans-serif" => "Source Sans Pro",
				"'Roboto Mono', sans-serif" => "Roboto Mono",
				"'Noto Sans', sans-serif" => "Noto Sans",
				"Inter, sans-serif" => "Inter",
				"Ubuntu, sans-serif" => "Ubuntu",
				"Mukta, sans-serif" => "Mukta",
				"Merriweather, sans-serif" => "Merriweather",
				"Rubik, sans-serif" => "Rubik",
				"Lora, sans-serif" => "Lora",
				"Quicksand, sans-serif" => "Quicksand",
				"'PT Serif', sans-serif" => "PT Serif",
				"Heebo, sans-serif" => "Heebo",
				"'Noto Serif', sans-serif" => "Noto Serif",
				"'DM Sans', sans-serif" => "DM Sans",
				"Manrope, sans-serif" => "Manrope",
				"Questrial, sans-serif" => "Questrial",
				"Chivo, sans-serif" => "Archivo",
				"Baskervville, sans-serif" => "Baskervville",
				"Mulish, sans-serif" => "Mulish",
		    )
		)
		) );
		$wp_customize->add_section( 'umum', array(
			'title' => 'Umum',
		  	'description'=> 'Ubah layout sesuai dengan selera dan keinginan anda..',
			'panel' => 'ThemesappPos',
		));
	
		// Warna =========================================================== 
		$wp_customize->add_section( 'color', array(
	    	'title' => 'Warna Situs',
		  	'description'=> 'Warna-warna yang ada dibawah ini adalah warna umum yang digunakan pada tema. Ubah warna-warna tersebut sesuai dengan selera dan keinginan anda.',
			'panel' => 'ThemesappPos',
	    ));

		$wp_customize->add_setting( 'desc1', array(
		  'capability' => 'edit_theme_options',
		  'default' => '',
		  'sanitize_callback' => 'sanitize_text_field',
		) );

		$wp_customize->add_control( 'desc1', array(
		  'type' => 'hidden',
		  'section' => 'color', // Add a default or your own section
		  'label' => '',
		  'description' => 'Dibawah ini adalah pengaturan umum warna pada situs',
		) );
	    $wp_customize->add_setting( 'utama' , array(
	        'default'     => "#821c1c",
	        'transport'   => 'refresh',
	    ));
	    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'utama', array(
	        'label'        => 'Warna Primer',
	        'section'    => 'color',
	    )));
	    $wp_customize->add_setting( 'gradient1' , array(
	        'default'     => "#821c1c",
	        'transport'   => 'refresh',
	    ));
	    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'gradient1', array(
	        'label'        => 'Warna Gradasi 1',
	        'section'    => 'color',
	    )));
	    $wp_customize->add_setting( 'gradient2' , array(
	        'default'     => "#2d2d2d",
	        'transport'   => 'refresh',
	    ));
	    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'gradient2', array(
	        'label'        => 'Warna Gradasi 2',
	        'section'    => 'color',
	    )));
	    $wp_customize->add_setting( 'title' , array(
	        'default'     => "#444",
	        'transport'   => 'refresh',
	    ));
	    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'title', array(
	        'label'        => 'Warna Judul Widget',
	        'section'    => 'color',
	    )));
	    $wp_customize->add_setting( 'garis' , array(
	        'default'     => "#e4b622",
	        'transport'   => 'refresh',
	    ));
	    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'garis', array(
	        'label'        => 'Warna Garis Widget',
	        'section'    => 'color',
	    )));
	    $wp_customize->add_setting( 'titlepost' , array(
	        'default'     => "#fff",
	        'transport'   => 'refresh',
	    ));
	    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'titlepost', array(
	        'label'        => 'Warna Judul Post Slider',
	        'section'    => 'color',
	    )));


		$wp_customize->add_setting( 'desc2', array(
		  'capability' => 'edit_theme_options',
		  'default' => '',
		  'sanitize_callback' => 'sanitize_text_field',
		) );

		$wp_customize->add_control( 'desc2', array(
		  'type' => 'hidden',
		  'section' => 'color', // Add a default or your own section
		  'label' => '',
		  'description' => '<hr> Dibawah ini adalah pengaturan warna pada navigasi',
		) );

	    $wp_customize->add_setting( 'bgmenu' , array(
	        'default'     => "#821c1c",
	        'transport'   => 'refresh',
	    ));
	    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'bgmenu', array(
	        'label'        => 'Warna Background Menu',
	        'section'    => 'color',
	    )));
	    $wp_customize->add_setting( 'txtmenu' , array(
	        'default'     => "#fff",
	        'transport'   => 'refresh',
	    ));
	    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'txtmenu', array(
	        'label'        => 'Warna Teks Menu',
	        'section'    => 'color',
	    )));
	    $wp_customize->add_setting( 'txthvrmenu' , array(
	        'default'     => "#e4b622",
	        'transport'   => 'refresh',
	    ));
	    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'txthvrmenu', array(
	        'label'        => 'Warna Hover Teks Menu',
	        'section'    => 'color',
	    )));
		$wp_customize->add_setting( 'desc3', array(
		  'capability' => 'edit_theme_options',
		  'default' => '',
		  'sanitize_callback' => 'sanitize_text_field',
		) );

		$wp_customize->add_control( 'desc3', array(
		  'type' => 'hidden',
		  'section' => 'color', // Add a default or your own section
		  'label' => '',
		  'description' => '<hr> Dibawah ini adalah pengaturan warna pada footer',
		) );

	    $wp_customize->add_setting( 'footergradient1' , array(
	        'default'     => "#545454",
	        'transport'   => 'refresh',
	    ));
	    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'footergradient1', array(
	        'label'        => 'Warna Gradasi 1',
	        'section'    => 'color',
	    )));
	    $wp_customize->add_setting( 'footergradient2' , array(
	        'default'     => "#000",
	        'transport'   => 'refresh',
	    ));
	    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'footergradient2', array(
	        'label'        => 'Warna Gradasi 2',
	        'section'    => 'color',
	    )));
	
	    $wp_customize->add_setting( 'txtfooter' , array(
	        'default'     => "#fff",
	        'transport'   => 'refresh',
	    ));
	    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'txtfooter', array(
	        'label'        => 'Warna Teks Footer',
	        'section'    => 'color',
	    )));
		/* Follow */
		$wp_customize->add_section( 'tombolfollow' , array(
		  'title'      => 'Media Sosial',     
		  'panel' => 'ThemesappPos',
		  'description'=> 'Berikut ini adalah pengaturan url tombol media sosial. Disini kamu bisa mengatur tombol mana yang ingin kamu tampilkan',
		));
		$wp_customize->add_setting( 'tombolfollowfacebook' , array(
			'default'    => '',
			'transport'  =>  'refresh'
		));
		$wp_customize->add_control('tombolfollowfacebook' , array(
			'section' => 'tombolfollow',
			'label' =>'URL Facebook',
			'type'=>'text',
			'input_attrs' => array(
            'placeholder' => 'Url Fanspage Facebook...',
        )
		));
		$wp_customize->add_setting( 'tombolfollowtwitter' , array(
			'default'    => '',
			'transport'  =>  'refresh'
		));
		$wp_customize->add_control('tombolfollowtwitter' , array(
			'section' => 'tombolfollow',
			'label' =>'URL Twitter',
			'type'=>'text',
			'input_attrs' => array(
            'placeholder' => 'Url Twitter...',
        )
		));
		$wp_customize->add_setting( 'tombolfollowinstagram' , array(
			'default'    => '',
			'transport'  =>  'refresh'
		));
		$wp_customize->add_control('tombolfollowinstagram' , array(
			'section' => 'tombolfollow',
			'label' =>'URL Instagram',
			'type'=>'text',
			'input_attrs' => array(
            'placeholder' => 'Url Instagram...',
        )
		));
		$wp_customize->add_setting( 'tombolfollowyoutube' , array(
			'default'    => '',
			'transport'  =>  'refresh'
		));
		$wp_customize->add_control('tombolfollowyoutube' , array(
			'section' => 'tombolfollow',
			'label' =>'URL Youtube',
			'type'=>'text',
			'input_attrs' => array(
            'placeholder' => 'Url Channel Youtube...',
        )
		));
		$wp_customize->add_setting( 'tombolfollowtelegram' , array(
			'default'    => '',
			'transport'  =>  'refresh'
		));
		$wp_customize->add_control('tombolfollowtelegram' , array(
			'section' => 'tombolfollow',
			'label' =>'URL Telegram',
			'type'=>'text',
			'input_attrs' => array(
            'placeholder' => 'Url Telegram...',
        )
		));
		$wp_customize->add_setting( 'tombolfollowdiscord' , array(
			'default'    => '',
			'transport'  =>  'refresh'
		));
		$wp_customize->add_control('tombolfollowdiscord' , array(
			'section' => 'tombolfollow',
			'label' =>'URL Discord',
			'type'=>'text',
			'input_attrs' => array(
            'placeholder' => 'Url Discord...',
        )
		));
		$wp_customize->add_setting( 'tombolfollowgnews' , array(
			'default'    => '',
			'transport'  =>  'refresh'
		));
		$wp_customize->add_control('tombolfollowgnews' , array(
			'section' => 'tombolfollow',
			'label' =>'URL Google News',
			'type'=>'text',
			'input_attrs' => array(
            'placeholder' => 'Url Google News...',
        )
		));


		$wp_customize->add_section( 'tampilan' , array(
		  'title'      => 'Tampilan', 
		  'panel' => 'ThemesappPos',
		  'description'=> 'Berikut ini adalah pengaturan tampilan pada tema',
		));


		$wp_customize->add_setting( 'mode' , array(
			'default'    => true,
			'transport'  =>  'refresh'
		));
		$wp_customize->add_control('mode' , array(
			'section' => 'tampilan',
			'label' =>'Tampilkan mode gelap dan terang',
			'type'=>'checkbox',
		));
		$wp_customize->add_setting( 'date' , array(
			'default'    => true,
			'transport'  =>  'refresh'
		));
		$wp_customize->add_control('date' , array(
			'section' => 'tampilan',
			'label' =>'Tampilkan tanggal pada versi desktop',
			'type'=>'checkbox',
		));
		$wp_customize->add_setting( 'featured' , array(
			'default'    => true,
			'transport'  =>  'refresh'
		));
		$wp_customize->add_control('featured' , array(
			'section' => 'tampilan',
			'label' =>'Tampilkan gambar unggulan halaman pos',
			'type'=>'checkbox',
		));
		$wp_customize->add_setting( 'layout',
		 array(
		    'default'    => 'layoutfull',
		    'type'       => 'theme_mod',
		 ));

		$wp_customize->add_control( new WP_Customize_Control(
		 $wp_customize,
		 'theme_layout',
		 array(
		    'label'      => 'Pilih Tipe Layout', 
		    'settings'   => 'layout',
		    'section'    => 'tampilan',
		    'type'    => 'select',
		    'choices' => array(
				"layoutfull" => "Lebar Penuh",
				"layoutbox" => "Box",
		    )
		)
		) );

		$wp_customize->add_section( 'inserted', array(
	    	'title' => 'Kode Khusus',
		  	'description'=> 'Dibawah ini adalah form kode yang dapat dimasukan ke dalam tema.',
			'panel' => 'ThemesappPos',
	    ));


        $wp_customize->add_setting( 'insertheader' );
        $wp_customize->add_control( new WP_Customize_Code_Editor_Control( $wp_customize, 'insertheader', array(
                'label' => 'Header Non AMP',
                'code_type' => 'text/html',
                'settings' => 'insertheader',
                'section' => 'inserted',
        )));
        $wp_customize->add_setting( 'insertfooter' );
        $wp_customize->add_control( new WP_Customize_Code_Editor_Control( $wp_customize, 'insertfooter', array(
                'label' => 'Footer Non AMP',
                'code_type' => 'text/html',
                'settings' => 'insertfooter',
                'section' => 'inserted',
        )));
        $wp_customize->add_setting( 'insertheaderamp' );
        $wp_customize->add_control( new WP_Customize_Code_Editor_Control( $wp_customize, 'insertheaderamp', array(
                'label' => 'Header AMP',
                'code_type' => 'text/html',
                'settings' => 'insertheaderamp',
                'section' => 'inserted',
        )));
        $wp_customize->add_setting( 'insertfooteramp' );
        $wp_customize->add_control( new WP_Customize_Code_Editor_Control( $wp_customize, 'insertfooteramp', array(
                'label' => 'Footer AMP',
                'code_type' => 'text/html',
                'settings' => 'insertfooteramp',
                'section' => 'inserted',
        )));



		$wp_customize->add_section( 'licPost' , array(
		  'title'      => 'Lisensi',     
		  'description'=> '',
		  'panel' => 'ThemesappPos',
		));

		$wp_customize->add_setting( 'lic' , array(
			'default'    => '',
			'transport'  =>  'postMessage'
		));
		$wp_customize->add_control('lic' , array(
			'section' => 'licPost',
			'label' =>'Lisensi Tema',
			'type'=>'text',
			'input_attrs' => array(
            'placeholder' => __( 'Masukan lisensi tema disini'),
        )
		));
}
add_action( 'customize_register', 'addCustomize' );

?>