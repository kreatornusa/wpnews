<?php 
function addscript() {
        $versi = '3.0.0.27';
        if (function_exists( 'is_amp_endpoint' ) && is_amp_endpoint()) {
        wp_deregister_script('jquery');
        }else{
        wp_enqueue_script('jquery', get_stylesheet_directory_uri() . '/assets/js/jquery-3.6.0.min.js',  array(), $versi, true );
        wp_enqueue_script('mode', get_stylesheet_directory_uri() . '/assets/js/darkmode.js',  array(), $versi, true );
        wp_enqueue_script('slick', get_stylesheet_directory_uri() . '/assets/js/slick.min.js',  array(), $versi, true );
        wp_enqueue_script('sticky', get_stylesheet_directory_uri() . '/assets/js/jquery.sticky-kit.min.js',  array(), $versi, true );
        wp_enqueue_script('magnific', get_stylesheet_directory_uri() . '/assets/js/jquery.magnific-popup.min.js',  array(), $versi, true );
        wp_enqueue_script('marquee', get_stylesheet_directory_uri() . '/assets/js/jquery.marquee.min.js',  array(), $versi, true );
        wp_enqueue_script('main', get_stylesheet_directory_uri() . '/assets/js/main.js',  array(), $versi, true );
        if (wp_is_mobile()):
            wp_enqueue_script('mobile', get_stylesheet_directory_uri() . '/assets/js/js-mobile.js',  array(), $versi, true );
        else:
            wp_enqueue_script('desktop', get_stylesheet_directory_uri() . '/assets/js/js-desktop.js',  array(), $versi, true );
        endif;
        if(is_author()) :
            wp_enqueue_script('author', get_stylesheet_directory_uri() . '/assets/js/js-author.js',  array(), $versi, true );
        endif;
        if(is_category()) :
            wp_enqueue_script('category', get_stylesheet_directory_uri() . '/assets/js/js-category.js',  array(), $versi, true );
        endif;
        if(is_home()) :
            wp_enqueue_script('home', get_stylesheet_directory_uri() . '/assets/js/js-home.js',  array(), $versi, true );
        endif;
        if(is_page()) :
            wp_enqueue_script('page', get_stylesheet_directory_uri() . '/assets/js/js-page.js',  array(), $versi, true );
        endif;
        if(is_page_template('trending.php')) :
            wp_enqueue_script('trending', get_stylesheet_directory_uri() . '/assets/js/js-trending.js',  array(), $versi, true );
        endif;
        if(is_page_template('indeks.php')) :
            wp_enqueue_script('moment', 'https://cdn.jsdelivr.net/momentjs/latest/moment.min.js',  array(), $versi, true );
            wp_enqueue_script('daterangepicker', 'https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js',  array(), $versi, true );
            wp_enqueue_script('indeks', get_stylesheet_directory_uri() . '/assets/js/js-indeks.js',  array(), $versi, true );
        endif;
        if(is_search()) :
            wp_enqueue_script('search', get_stylesheet_directory_uri() . '/assets/js/js-search.js',  array(), $versi, true );
        endif;
        if(is_single()) :
            wp_enqueue_script('fslightbox', get_stylesheet_directory_uri() . '/assets/js/fslightbox.js',  array(), $versi, true );
            wp_enqueue_script('single', get_stylesheet_directory_uri() . '/assets/js/js-single.js',  array(), $versi, true );
        endif;
        if(is_tag()) :
            wp_enqueue_script('tag', get_stylesheet_directory_uri() . '/assets/js/js-tag.js',  array(), $versi, true );
        endif;
    }
}
add_action( 'wp_enqueue_scripts', 'addscript' );

function addattrscript( $tag, $handle, $src ) {
    if (
    'hoverintent-js' === $handle 
    ||'admin-bar' === $handle 
    ||'wp-embed' === $handle 
    ||'js-mobile' === $handle 
    ||'js-desktop' === $handle 
    ||'js-infinite' === $handle 
    ||'jsauthor' === $handle 
    ||'jscategory' === $handle 
    ||'jshome' === $handle 
    ||'jspage' === $handle 
    ||'jstrending' === $handle 
    ||'jsindeks' === $handle 
    ||'jssearch' === $handle 
    ||'jssingle' === $handle 
    ||'jstag' === $handle 
    ):
    $tag = str_replace( "src=", "async='async' src=", $tag );
    endif;
    return $tag;
}
add_filter( 'script_loader_tag', 'addattrscript', 10, 3 );
function comments_reply() {
    if( is_singular() && comments_open() && ( get_option( 'thread_comments' ) == 1) ) {
        wp_enqueue_script( 'comment-reply', '/wp-includes/js/comment-reply.min.js', array(), false, true );
    }
}
add_action(  'wp_enqueue_scripts', 'comments_reply' );
?>