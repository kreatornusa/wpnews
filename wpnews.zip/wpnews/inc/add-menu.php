<?php 
function menu_utama(){
  $args = array(
    'theme_location'  => 'menu_utama', // ID menu yang akan dipanggil
    'menu'            => 'Menu Desktop', // Judul menu di saat pengaturan menu
    'container'       => 'nav', // tipe tag pembuka dari sebuah menu
    'container_class' => '', // class dari tag pembuka
    'container_id'    => '', // id dari tag pembuka
    'menu_class'      => 'primary-menu', // class dari menu (ul)
    'menu_id'         => '', // id dari menu (ul)
    'echo'            => true, // pengaturan menu (tampil isinya true dan tidak tampil isinya false)
    'fallback_cb'     => 'wp_page_menu',
    'before'          => '', // tag pembuka sebelum link menu (dalam html)
    'after'           => '', // tag penutup sesudah link menu (dalam html)
    'link_before'     => '', // html / tulisan sebelum teks link
    'link_after'      => '', // html / tulisan sesudah teks link
    'items_wrap'      => '<ul id = "%1$s" class = "nav__wrap %2$s">%3$s</ul>', // pengaturan widget menu di dalam ul
    'depth'           => 0,
    'walker'          => '', // merujuk ke fungsi walker baru
  );
  wp_nav_menu($args);
}

function mobile_menu(){
  $args = array(
    'theme_location'  => 'mobile_menu', // ID menu yang akan dipanggil
    'menu'            => 'Menu Mobile', // Judul menu di saat pengaturan menu
    'container'       => 'nav', // tipe tag pembuka dari sebuah menu
    'container_class' => '', // class dari tag pembuka
    'container_id'    => '', // id dari tag pembuka
    'menu_class'      => 'primary-menu', // class dari menu (ul)
    'menu_id'         => '', // id dari menu (ul)
    'echo'            => true, // pengaturan menu (tampil isinya true dan tidak tampil isinya false)
    'fallback_cb'     => 'wp_page_menu',
    'before'          => '', // tag pembuka sebelum link menu (dalam html)
    'after'           => '', // tag penutup sesudah link menu (dalam html)
    'link_before'     => '', // html / tulisan sebelum teks link
    'link_after'      => '', // html / tulisan sesudah teks link
    'items_wrap'      => '<ul id = "%1$s" class = "nav__wrap %2$s">%3$s</ul>', // pengaturan widget menu di dalam ul
    'depth'           => 0,
    'walker'          => '', // merujuk ke fungsi walker baru
  );
  wp_nav_menu($args);
}

function network_menu(){
  $args = array(
    'theme_location'  => 'network_menu', // ID menu yang akan dipanggil
    'menu'            => 'Network Menu', // Judul menu di saat pengaturan menu
    'container'       => '', // tipe tag pembuka dari sebuah menu
    'container_class' => '', // class dari tag pembuka
    'container_id'    => '', // id dari tag pembuka
    'menu_class'      => 'widget LinkList', // class dari menu (ul)
    'menu_id'         => '', // id dari menu (ul)
    'echo'            => true, // pengaturan menu (tampil isinya true dan tidak tampil isinya false)
    'fallback_cb'     => 'wp_page_menu',
    'before'          => '', // tag pembuka sebelum link menu (dalam html)
    'after'           => '', // tag penutup sesudah link menu (dalam html)
    'link_before'     => '', // html / tulisan sebelum teks link
    'link_after'      => '', // html / tulisan sesudah teks link
    'items_wrap'      => '<ul id = "%1$s" class = "%2$s network__menu">%3$s</ul>', // pengaturan widget menu di dalam ul
    'depth'           => 0,
    'walker'          => '', // merujuk ke fungsi walker baru
  );
  wp_nav_menu($args);
}

function sidebarmenu(){
  $args = array(
    'theme_location'  => 'sidebarmenu', // ID menu yang akan dipanggil
    'menu'            => 'Sidebar Menu', // Judul menu di saat pengaturan menu
    'container'       => 'nav', // tipe tag pembuka dari sebuah menu
    'container_class' => '', // class dari tag pembuka
    'container_id'    => '', // id dari tag pembuka
    'menu_class'      => 'primary-menu', // class dari menu (ul)
    'menu_id'         => '', // id dari menu (ul)
    'echo'            => true, // pengaturan menu (tampil isinya true dan tidak tampil isinya false)
    'fallback_cb'     => 'wp_page_menu',
    'before'          => '', // tag pembuka sebelum link menu (dalam html)
    'after'           => '', // tag penutup sesudah link menu (dalam html)
    'link_before'     => '', // html / tulisan sebelum teks link
    'link_after'      => '', // html / tulisan sesudah teks link
    'items_wrap'      => '<ul id = "%1$s" class = "nav__wrap %2$s">%3$s</ul>', // pengaturan widget menu di dalam ul
    'depth'           => 0,
    'walker'          => '', // merujuk ke fungsi walker baru
  );
  wp_nav_menu($args);
}
$register_menu = array(
    'menu_utama' => 'Menu Desktop',
    'mobile_menu' => 'Menu Mobile',
    'network_menu' => 'Network Menu',
    'sidebarmenu' => 'Sidebar Menu',
);
register_nav_menus($register_menu);

?>