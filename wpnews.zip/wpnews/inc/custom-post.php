<?php 
add_filter( 'wpseo_metabox_prio', 'yoast_metabox_down' );
function yoast_metabox_down( $priority ) {
    return 'low';
}
function info_add_metabox() {
    add_meta_box(
        'info_metabox_id',
        'Tampilan Sumber & Editor',
        'info_metabox_form',
        'post',
        'normal',
        'high'
    );
}
add_action( 'add_meta_boxes', 'info_add_metabox' );

function info_metabox_form() {
    global $post;
    $meta = get_post_meta( $post->ID, 'info', true ); ?>
    <input type="hidden" name="info_metabox" value="<?php echo wp_create_nonce( basename(__FILE__) ); ?>">
    <p>
        <label id="info[sumber]" style="margin: 5px 0;display: block;">Sumber :</label>
        <input type="text" name="info[sumber]" id="info[sumber]" class="regular-text" value="<?php echo isset($meta['sumber']) ? $meta['sumber'] : ''; ?>" style="width:100%;">
    </p>
    <p>
    <label for="info[editor]">Editor:</label>
    <?php
    if(empty($meta['editor'])){
        $valueeditor = "-1";
    }else{
        $valueeditor = $meta['editor'];
    }
    wp_dropdown_users( array(
        'include' => '',
        'show_option_none'   => 'Pilih Editor',
        'who' => 'authors',
        'name' => 'info[editor]',
        'id' => 'info[editor]',
        'selected' => $valueeditor,
        'include_selected' => true,
        'orderby'           => 'display_name',
        'order'             => 'ASC'
    ) );
    ?>
    </p>
<?php
}

function info_metabox_control( $post_id ) {
    if ( !wp_verify_nonce( $_POST['info_metabox'], basename(__FILE__) )) {
        return $post_id;
    }
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
        return $post_id;
    }
    if ( 'page' === $_POST['post_type'] ) {
        if ( !current_user_can( 'edit_page', $post_id ) ) {
            return $post_id;
        } elseif ( !current_user_can( 'edit_post', $post_id ) ) {
            return $post_id;
        }
    }

    $old_info = get_post_meta( $post_id, 'info', true );
    $new_info = $_POST['info'];

    if ( $new_info && $new_info !== $old_info ) {
        update_post_meta( $post_id, 'info', $new_info );
    } elseif ( '' === $new_info && $old_info ) {
        delete_post_meta( $post_id, 'info', $old_info );
    }
}
add_action( 'save_post', 'info_metabox_control' );

?>