<?php
function topicoutlineViewDesktop($title,$tag1,$tag2,$tag3){
  $tags1 = get_term_by('slug', $tag1, 'post_tag');
  $tags2 = get_term_by('slug', $tag2, 'post_tag');
  $tags3 = get_term_by('slug', $tag3, 'post_tag');
  $tag_id1 = $tags1->term_id;
  $tag_id2 = $tags2->term_id;
  $tag_id3 = $tags3->term_id;
  $tag_permalink1 = get_tag_link($tag_id1);
  $tag_permalink2 = get_tag_link($tag_id2);
  $tag_permalink3 = get_tag_link($tag_id3);
  $tag_name1 = $tags1->name;
  $tag_name2 = $tags2->name;
  $tag_name3 = $tags3->name;

	global $post;
	if(!empty($tag1) && $tag1 != "-1"):
		$args1 = array(
			'tag' => $tag1,
			'post_type' => 'post',
			'post_status' => 'publish',
			'posts_per_page'=> 1
		);
	endif;
	if(!empty($tag2) && $tag2 != "-1"):
		$args2 = array(
			'tag' => $tag2,
			'post_type' => 'post',
			'post_status' => 'publish',
			'posts_per_page'=> 1
		);
	endif;
	if(!empty($tag3) && $tag3 != "-1"):
		$args3 = array(
			'tag' => $tag3,
			'post_type' => 'post',
			'post_status' => 'publish',
			'posts_per_page'=> 1
		);
	endif;

	$my_query1 = new WP_Query( $args1 );
	$my_query2 = new WP_Query( $args2 );
	$my_query3 = new WP_Query( $args3 );

	?>
     <div class="widget topik">
        <?php if(!empty($title)): ?>
	     	<div class="widget-header">
	     		<h3 class="title"><?php echo $title; ?></h3>
	     	</div>
	      <?php endif; ?>
	     	<div class="widget-content">
	     		<div class="topik-box row">


					<?php if ( $my_query1->have_posts() ): 
					while ( $my_query1->have_posts() ) {
					$my_query1->the_post();
					?>
     			<div class="topik-item col-4">
     				<div class="topik-image media-image">
              	<?php echo customthumbnail($post->ID, "image_211_211"); ?>
     				</div>
     				<div class="topik-content">
     					<div class="topik-title">
     						<h2><a class="topik-link media-link" href="<?php echo $tag_permalink1; ?>">#<?php echo $tag_name1; ?></a></h2>
     					</div>
     					<div class="topik-count"><?php echo $tags1->count; ?> Artikel
     					</div>
     				</div>
     			</div>
					<?php
					}
					endif;
					wp_reset_postdata();
					?>
					<?php if ( $my_query2->have_posts() ): 
					while ( $my_query2->have_posts() ) {
					$my_query2->the_post();
					?>
     			<div class="topik-item col-4">
     				<div class="topik-image media-image">
              	<?php echo customthumbnail($post->ID, "image_211_211"); ?>
     				</div>
     				<div class="topik-content">
     					<div class="topik-title">
     						<h2><a class="topik-link media-link" href="<?php echo $tag_permalink2; ?>">#<?php echo $tag_name2; ?></a></h2>
     					</div>
     					<div class="topik-count"><?php echo $tags2->count; ?> Artikel
     					</div>
     				</div>
     			</div>
					<?php
					}
					endif;
					wp_reset_postdata();
					?>
					<?php if ( $my_query3->have_posts() ): 
					while ( $my_query3->have_posts() ) {
					$my_query3->the_post();
					?>
     			<div class="topik-item col-4">
     				<div class="topik-image media-image">
              	<?php echo customthumbnail($post->ID, "image_211_211"); ?>
     				</div>
     				<div class="topik-content">
     					<div class="topik-title">
     						<h2><a class="topik-link media-link" href="<?php echo $tag_permalink3; ?>">#<?php echo $tag_name3; ?></a></h2>
     					</div>
     					<div class="topik-count"><?php echo $tags3->count; ?> Artikel
     					</div>
     				</div>
     			</div>
					<?php
					}
					endif;
					wp_reset_postdata();
					?>

	     		</div>
	     	</div>
	     </div>
	<?php 
}
function topicoutlineViewMobile($title,$tag1,$tag2,$tag3){
  $tags1 = get_term_by('slug', $tag1, 'post_tag');
  $tags2 = get_term_by('slug', $tag2, 'post_tag');
  $tags3 = get_term_by('slug', $tag3, 'post_tag');
  $tag_id1 = $tags1->term_id;
  $tag_id2 = $tags2->term_id;
  $tag_id3 = $tags3->term_id;
  $tag_permalink1 = get_tag_link($tag_id1);
  $tag_permalink2 = get_tag_link($tag_id2);
  $tag_permalink3 = get_tag_link($tag_id3);
  $tag_name1 = $tags1->name;
  $tag_name2 = $tags2->name;
  $tag_name3 = $tags3->name;

	global $post;
	if(!empty($tag1) && $tag1 != "-1"):
		$args1 = array(
			'tag' => $tag1,
			'post_type' => 'post',
			'post_status' => 'publish',
			'posts_per_page'=> 1
		);
	endif;
	if(!empty($tag2) && $tag2 != "-1"):
		$args2 = array(
			'tag' => $tag2,
			'post_type' => 'post',
			'post_status' => 'publish',
			'posts_per_page'=> 1
		);
	endif;
	if(!empty($tag3) && $tag3 != "-1"):
		$args3 = array(
			'tag' => $tag3,
			'post_type' => 'post',
			'post_status' => 'publish',
			'posts_per_page'=> 1
		);
	endif;

	$my_query1 = new WP_Query( $args1 );
	$my_query2 = new WP_Query( $args2 );
	$my_query3 = new WP_Query( $args3 );

	?>
     <div class="widget topik">
        <?php if(!empty($title)): ?>
	     	<div class="widget-header">
	     		<h3 class="title"><?php echo $title; ?></h3>
	     	</div>
	      <?php endif; ?>
	     	<div class="widget-content">
	     		<div class="topik-box row">


					<?php if ( $my_query1->have_posts() ): 
					while ( $my_query1->have_posts() ) {
					$my_query1->the_post();
					?>
     			<div class="topik-item col-6">
     				<div class="topik-image media-image">
              	<?php echo customthumbnail($post->ID, "image_211_211"); ?>
     				</div>
     				<div class="topik-content">
     					<div class="topik-title">
     						<h2><a class="topik-link media-link" href="<?php echo $tag_permalink1; ?>">#<?php echo $tag_name1; ?></a></h2>
     					</div>
     					<div class="topik-count"><?php echo $tags1->count; ?> Artikel
     					</div>
     				</div>
     			</div>
					<?php
					}
					endif;
					wp_reset_postdata();
					?>
					<?php if ( $my_query2->have_posts() ): 
					while ( $my_query2->have_posts() ) {
					$my_query2->the_post();
					?>
     			<div class="topik-item col-6">
     				<div class="topik-image media-image">
              	<?php echo customthumbnail($post->ID, "image_211_211"); ?>
     				</div>
     				<div class="topik-content">
     					<div class="topik-title">
     						<h2><a class="topik-link media-link" href="<?php echo $tag_permalink2; ?>">#<?php echo $tag_name2; ?></a></h2>
     					</div>
     					<div class="topik-count"><?php echo $tags2->count; ?> Artikel
     					</div>
     				</div>
     			</div>
					<?php
					}
					endif;
					wp_reset_postdata();
					?>
					<?php if ( $my_query3->have_posts() ): 
					while ( $my_query3->have_posts() ) {
					$my_query3->the_post();
					?>
     			<div class="topik-item col-6">
     				<div class="topik-image media-image">
              	<?php echo customthumbnail($post->ID, "image_211_211"); ?>
     				</div>
     				<div class="topik-content">
     					<div class="topik-title">
     						<h2><a class="topik-link media-link" href="<?php echo $tag_permalink3; ?>">#<?php echo $tag_name3; ?></a></h2>
     					</div>
     					<div class="topik-count"><?php echo $tags3->count; ?> Artikel
     					</div>
     				</div>
     			</div>
					<?php
					}
					endif;
					wp_reset_postdata();
					?>

	     		</div>
	     	</div>
	     </div>
	<?php 
}
class topicoutline extends WP_Widget {

	public function __construct() {
		$idwidget = 'topicoutline';
		$namewidget = '📌 Topik';
		$descwidget = 'Topik khusus berdasarkan tag yang dipilih dan ditampilkan dalam bentuk grid di beranda.';
		parent::__construct($idwidget, $namewidget, array('description'=> $descwidget));
	}
	public function widget( $args, $instance ) {
		if($instance['mobile'] == 'yes'){
			if (function_exists( 'is_amp_endpoint' ) && is_amp_endpoint()) {
				topicoutlineViewMobile($instance['title'], $instance['tag1'], $instance['tag2'], $instance['tag3']);
			}elseif (wp_is_mobile()) {
				topicoutlineViewMobile($instance['title'], $instance['tag1'], $instance['tag2'], $instance['tag3']);
			}
		}
		if($instance['desktop'] == 'yes'){
			if (function_exists( 'is_amp_endpoint' ) && is_amp_endpoint()) {
			}elseif (wp_is_mobile()) {
			}else{
				topicoutlineViewDesktop($instance['title'], $instance['tag1'], $instance['tag2'], $instance['tag3']);
			}
		}
	}
	public function update( $new_instance, $old_instance ) {
		$instance = array();
		if ( ! empty( $new_instance['title'] ) ) {
			$instance['title'] = sanitize_text_field( $new_instance['title'] );
		}
		if ( ! empty( $new_instance['tag1'] ) ) {
			$instance['tag1'] = sanitize_text_field( $new_instance['tag1'] );
		}
		if ( ! empty( $new_instance['tag2'] ) ) {
			$instance['tag2'] = sanitize_text_field( $new_instance['tag2'] );
		}
		if ( ! empty( $new_instance['tag3'] ) ) {
			$instance['tag3'] = sanitize_text_field( $new_instance['tag3'] );
		}
		$instance['desktop'] = isset( $new_instance['desktop'] ) ? 'yes' : 'no';
		$instance['mobile'] = isset( $new_instance['mobile'] ) ? 'yes' : 'no';
		return $instance;
	}

	public function form( $instance ) {
		$defaults = array(
			'title' => '',
			'tag1' => '-1',
			'tag2' => '-1',
			'tag3' => '-1',
			'desktop' => 'yes',
			'mobile' => 'yes',
		);
		$instance = wp_parse_args( (array) $instance, $defaults ); 
		?>
		<div class="related-form-controls">
			<p>
				<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:' ); ?></label>
				<input type="text" class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" value="<?php echo $instance['title']; ?>" />
			</p>
			<p>
				<label for="<?php echo $this->get_field_id( 'tag1' ); ?>"><?php echo 'Topik 1:'; ?></label>
				<select id="<?php echo $this->get_field_id('tag1'); ?>" name="<?php echo $this->get_field_name('tag1'); ?>" class="widefat" style="width:100%;" required>
					<option <?php selected( $instance['tag1'], "-1" ); ?> value="-1">Pilih Tag</option>
					<?php foreach(get_terms('post_tag','parent=0&hide_empty=0') as $term) { ?>
						<option <?php selected( $instance['tag1'], $term->slug ); ?> value="<?php echo $term->slug; ?>"><?php echo $term->name; ?></option>
					<?php } ?>      
				</select>
			</p>
			<p>
				<label for="<?php echo $this->get_field_id( 'tag2' ); ?>"><?php echo 'Topik 2:'; ?></label>
				<select id="<?php echo $this->get_field_id('tag2'); ?>" name="<?php echo $this->get_field_name('tag2'); ?>" class="widefat" style="width:100%;" required>
					<option <?php selected( $instance['tag2'], "-1" ); ?> value="-1">Pilih Tag</option>
					<?php foreach(get_terms('post_tag','parent=0&hide_empty=0') as $term) { ?>
						<option <?php selected( $instance['tag2'], $term->slug ); ?> value="<?php echo $term->slug; ?>"><?php echo $term->name; ?></option>
					<?php } ?>      
				</select>
			</p>
			<p>
				<label for="<?php echo $this->get_field_id( 'tag3' ); ?>"><?php echo 'Topik 3:'; ?></label>
				<select id="<?php echo $this->get_field_id('tag3'); ?>" name="<?php echo $this->get_field_name('tag3'); ?>" class="widefat" style="width:100%;" required>
					<option <?php selected( $instance['tag3'], "-1" ); ?> value="-1">Pilih Tag</option>
					<?php foreach(get_terms('post_tag','parent=0&hide_empty=0') as $term) { ?>
						<option <?php selected( $instance['tag3'], $term->slug ); ?> value="<?php echo $term->slug; ?>"><?php echo $term->name; ?></option>
					<?php } ?>      
				</select>
			</p>
			<hr>
			<h3>Pengaturan Tampilan</h3>
			<p>
				<input type="checkbox" id="<?php echo $this->get_field_id( 'desktop' ); ?>" name="<?php echo $this->get_field_name( 'desktop' ); ?>" value="yes"<?php checked( 'yes', $instance['desktop'] ); ?>>
				<label for="<?php echo $this->get_field_id( 'desktop' ); ?>">Tampilkan dalam versi desktop</label><br>

				<input type="checkbox" id="<?php echo $this->get_field_id( 'mobile' ); ?>" name="<?php echo $this->get_field_name( 'mobile' ); ?>" value="yes"<?php checked( 'yes', $instance['mobile'] ); ?>>
				<label for="<?php echo $this->get_field_id( 'mobile' ); ?>">Tampilkan dalam versi mobile</label>
			</p>
		</div>
		<?php
	}
}

function topicoutlineload() {
	register_widget( 'topicoutline' );
}
add_action( 'widgets_init', 'topicoutlineload' ); 
?>