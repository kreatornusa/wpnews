<?php
function sliderheadlineViewDesktop($title, $category, $jml){
	global $post;
	if(!empty($category) && $category != "-1"):
		$args = array(
			'category_name' => $category,
			'post_type' => 'post',
			'post_status' => 'publish',
			'posts_per_page'=> $jml
		);
	else:
		$args = array(
			'post_type' => 'post',
			'post_status' => 'publish',
			'posts_per_page'=> $jml
		);
	endif;
	$my_query = new WP_Query( $args );
	if ( $my_query->have_posts() ): ?>
     <div class="widget slider">
        <?php if(!empty($title)): ?>
	     	<div class="widget-header">
	     		<h3 class="title"><?php echo $title; ?></h3>
	     	</div>
	      <?php endif; ?>
	     	<div class="widget-content">
	     		<div class="slider-box">
						<?php
						while ( $my_query->have_posts() ) {
							$my_query->the_post();
							?>
				     			<div class="slider-item">
				     				<div class="slider-image media-image">
				              	<?php echo customthumbnail($post->ID, "image_640_360"); ?>
				     				</div>
				     				<div class="slider-content">
				     					<div class="slider-category"><a href="<?php echo linkcategory(); ?>"><?php echo labelcategory(); ?></a></div>
				     					<div class="slider-title">
				     						<h2><a class="slider-link media-link" href="<?php echo get_permalink(); ?>"><?php echo get_the_title(); ?></a></h2>
				     					</div>
				     					<div class="slider-date"><?php echo timeago(); ?></div>
				     					<div class="slider-snippet"><?php echo themesapp_excerpt(100); ?></div>
				     				</div>
				     			</div>
							<?php
						}
						wp_reset_postdata();
						?>
	     		</div>
	     	</div>
     </div>
	<?php endif;
}
function sliderheadlineViewMobile($title, $category, $jml){
	global $post;
	if(!empty($category) && $category != "-1"):
		$args = array(
			'category_name' => $category,
			'post_type' => 'post',
			'post_status' => 'publish',
			'posts_per_page'=> $jml
		);
	else:
		$args = array(
			'post_type' => 'post',
			'post_status' => 'publish',
			'posts_per_page'=> $jml
		);
	endif;
	$my_query = new WP_Query( $args );
	if ( $my_query->have_posts() ): ?>
     <div class="widget slider">
        <?php if(!empty($title)): ?>
	     	<div class="widget-header">
	     		<h3 class="title"><?php echo $title; ?></h3>
	     	</div>
	      <?php endif; ?>
	     	<div class="widget-content">
	     		<div class="slider-box">
						<?php
						while ( $my_query->have_posts() ) {
							$my_query->the_post();
							?>
				     			<div class="slider-item">
				     				<div class="slider-image media-image">
				              	<?php echo customthumbnail($post->ID, "image_640_360"); ?>
				     				</div>
				     				<div class="slider-content">
				     					<div class="slider-category"><a href="<?php echo linkcategory(); ?>"><?php echo labelcategory(); ?></a></div>
				     					<div class="slider-title">
				     						<h2><a class="slider-link media-link" href="<?php echo get_permalink(); ?>"><?php echo get_the_title(); ?></a></h2>
				     					</div>
				     					<div class="slider-date"><?php echo timeago(); ?></div>
				     					<div class="slider-snippet"><?php echo themesapp_excerpt(100); ?></div>
				     				</div>
				     			</div>
							<?php
						}
						wp_reset_postdata();
						?>
	     		</div>
	     	</div>
     </div>
	<?php endif;
}
class sliderheadline extends WP_Widget {

	public function __construct() {
		$idwidget = 'sliderheadline';
		$namewidget = '📌 Slider Headline';
		$descwidget = 'Headline besar di beranda yang ditampilkan dalam bentuk slider.';
		parent::__construct($idwidget, $namewidget, array('description'=> $descwidget));
	}
	public function widget( $args, $instance ) {
		if($instance['mobile'] == 'yes'){
			if (function_exists( 'is_amp_endpoint' ) && is_amp_endpoint()) {
				sliderheadlineViewMobile($instance['title'], $instance['headline'], $instance['amountmobile']);
			}elseif (wp_is_mobile()) {
				sliderheadlineViewMobile($instance['title'], $instance['headline'], $instance['amountmobile']);
			}
		}
		if($instance['desktop'] == 'yes'){
			if (function_exists( 'is_amp_endpoint' ) && is_amp_endpoint()) {
			}elseif (wp_is_mobile()) {
			}else{
				sliderheadlineViewDesktop($instance['title'], $instance['headline'], $instance['amountdesktop']);
			}
		}
	}
	public function update( $new_instance, $old_instance ) {
		$instance = array();
		if ( ! empty( $new_instance['title'] ) ) {
			$instance['title'] = sanitize_text_field( $new_instance['title'] );
		}
		if ( ! empty( $new_instance['headline'] ) ) {
			$instance['headline'] = sanitize_text_field( $new_instance['headline'] );
		}
		if ( ! empty( $new_instance['amountdesktop'] ) ) {
			$instance['amountdesktop'] = sanitize_text_field( $new_instance['amountdesktop'] );
		}
		if ( ! empty( $new_instance['amountmobile'] ) ) {
			$instance['amountmobile'] = sanitize_text_field( $new_instance['amountmobile'] );
		}
		$instance['desktop'] = isset( $new_instance['desktop'] ) ? 'yes' : 'no';
		$instance['mobile'] = isset( $new_instance['mobile'] ) ? 'yes' : 'no';
		return $instance;
	}

	public function form( $instance ) {
		$defaults = array(
			'title' => '',
			'headline' => '-1',
			'amountdesktop' => '4',
			'amountmobile' => '4',
			'desktop' => 'yes',
			'mobile' => 'yes',
		);
		$instance = wp_parse_args( (array) $instance, $defaults ); 
		?>
		<div class="related-form-controls">
			<p>
				<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:' ); ?></label>
				<input type="text" class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" value="<?php echo $instance['title']; ?>" />
			</p>
			<hr>
			<h3>Pengaturan Headline</h3>
			<p>
				<label for="<?php echo $this->get_field_id( 'headline' ); ?>"><?php echo 'Kategori Headline:'; ?></label>
				<select id="<?php echo $this->get_field_id('headline'); ?>" name="<?php echo $this->get_field_name('headline'); ?>" class="widefat" style="width:100%;" required>
					<option <?php selected( $instance['headline'], "-1" ); ?> value="-1">Pilih Headline</option>
					<?php foreach(get_terms('category','parent=0&hide_empty=0') as $term) { ?>
						<option <?php selected( $instance['headline'], $term->slug ); ?> value="<?php echo $term->slug; ?>"><?php echo $term->name; ?></option>
					<?php } ?>      
				</select>
			</p>
			<p>
				<label for="<?php echo $this->get_field_id( 'amountdesktop' ); ?>"><?php echo 'Jumlah pos di desktop:'; ?></label>
				<input type="number" class="widefat" id="<?php echo $this->get_field_id( 'amountdesktop' ); ?>" name="<?php echo $this->get_field_name( 'amountdesktop' ); ?>" min="1" max="10" value="<?php echo $instance['amountdesktop']; ?>" required/>
			</p>
			<p>
				<label for="<?php echo $this->get_field_id( 'amountmobile' ); ?>"><?php echo 'Jumlah pos di mobile:'; ?></label>
				<input type="number" class="widefat" id="<?php echo $this->get_field_id( 'amountmobile' ); ?>" name="<?php echo $this->get_field_name( 'amountmobile' ); ?>" min="1" max="10" value="<?php echo $instance['amountmobile']; ?>" required/>
			</p>
			<hr>
			<h3>Pengaturan Tampilan</h3>
			<p>
				<input type="checkbox" id="<?php echo $this->get_field_id( 'desktop' ); ?>" name="<?php echo $this->get_field_name( 'desktop' ); ?>" value="yes"<?php checked( 'yes', $instance['desktop'] ); ?>>
				<label for="<?php echo $this->get_field_id( 'desktop' ); ?>">Tampilkan dalam versi desktop</label><br>

				<input type="checkbox" id="<?php echo $this->get_field_id( 'mobile' ); ?>" name="<?php echo $this->get_field_name( 'mobile' ); ?>" value="yes"<?php checked( 'yes', $instance['mobile'] ); ?>>
				<label for="<?php echo $this->get_field_id( 'mobile' ); ?>">Tampilkan dalam versi mobile</label>
			</p>
		</div>
		<?php
	}
}

function sliderheadlineload() {
	register_widget( 'sliderheadline' );
}
add_action( 'widgets_init', 'sliderheadlineload' );

function slidercustomViewDesktop($title, $slider1, $slider2, $slider3, $slider4){
	global $post;
	$args1 = array(
		'p' => $slider1,
		'post_type' => 'post',
		'post_status' => 'publish',
	);
	$args2 = array(
		'p' => $slider2,
		'post_type' => 'post',
		'post_status' => 'publish',
	);
	$args3 = array(
		'p' => $slider3,
		'post_type' => 'post',
		'post_status' => 'publish',
	);
	$args4 = array(
		'p' => $slider4,
		'post_type' => 'post',
		'post_status' => 'publish',
	);
	
	$my_query1 = new WP_Query( $args1 );
	$my_query2 = new WP_Query( $args2 );
	$my_query3 = new WP_Query( $args3 );
	$my_query4 = new WP_Query( $args4 );

	if ( $my_query1->have_posts() ): ?>
     <div class="widget slider">
        <?php if(!empty($title)): ?>
	     	<div class="widget-header">
	     		<h3 class="title"><?php echo $title; ?></h3>
	     	</div>
	      <?php endif; ?>
	     	<div class="widget-content">
	     		<div class="slider-box">
							<?php
							while ( $my_query1->have_posts() ) {
								$my_query1->the_post();
								?>
				     			<div class="slider-item">
				     				<div class="slider-image media-image">
				              	<?php echo customthumbnail($post->ID, "image_640_360"); ?>
				     				</div>
				     				<div class="slider-content">
				     					<div class="slider-category"><a href="<?php echo linkcategory(); ?>"><?php echo labelcategory(); ?></a></div>
				     					<div class="slider-title">
				     						<h2><a class="slider-link media-link" href="<?php echo get_permalink(); ?>"><?php echo get_the_title(); ?></a></h2>
				     					</div>
				     					<div class="slider-date"><?php echo timeago(); ?></div>
				     					<div class="slider-snippet"><?php echo themesapp_excerpt(100); ?></div>
				     				</div>
				     			</div>
								<?php
							}
							wp_reset_postdata();
						endif;
							?>
							<?php
						if ( $my_query2->have_posts() ):
							while ( $my_query2->have_posts() ) {
								$my_query2->the_post();
								?>
				     			<div class="slider-item">
				     				<div class="slider-image media-image">
				              	<?php echo customthumbnail($post->ID, "image_640_360"); ?>
				     				</div>
				     				<div class="slider-content">
				     					<div class="slider-category"><a href="<?php echo linkcategory(); ?>"><?php echo labelcategory(); ?></a></div>
				     					<div class="slider-title">
				     						<h2><a class="slider-link media-link" href="<?php echo get_permalink(); ?>"><?php echo get_the_title(); ?></a></h2>
				     					</div>
				     					<div class="slider-date"><?php echo timeago(); ?></div>
				     					<div class="slider-snippet"><?php echo themesapp_excerpt(100); ?></div>
				     				</div>
				     			</div>
								<?php
							}
							wp_reset_postdata();
						endif;
							?>
							<?php
						if ( $my_query3->have_posts() ):
							while ( $my_query3->have_posts() ) {
								$my_query3->the_post();
								?>
				     			<div class="slider-item">
				     				<div class="slider-image media-image">
				              	<?php echo customthumbnail($post->ID, "image_640_360"); ?>
				     				</div>
				     				<div class="slider-content">
				     					<div class="slider-category"><a href="<?php echo linkcategory(); ?>"><?php echo labelcategory(); ?></a></div>
				     					<div class="slider-title">
				     						<h2><a class="slider-link media-link" href="<?php echo get_permalink(); ?>"><?php echo get_the_title(); ?></a></h2>
				     					</div>
				     					<div class="slider-date"><?php echo timeago(); ?></div>
				     					<div class="slider-snippet"><?php echo themesapp_excerpt(100); ?></div>
				     				</div>
				     			</div>
								<?php
							}
							wp_reset_postdata();
						endif;
							?>
							<?php
						if ( $my_query4->have_posts() ):
							while ( $my_query4->have_posts() ) {
								$my_query4->the_post();
								?>
				     			<div class="slider-item">
				     				<div class="slider-image media-image">
				              	<?php echo customthumbnail($post->ID, "image_640_360"); ?>
				     				</div>
				     				<div class="slider-content">
				     					<div class="slider-category"><a href="<?php echo linkcategory(); ?>"><?php echo labelcategory(); ?></a></div>
				     					<div class="slider-title">
				     						<h2><a class="slider-link media-link" href="<?php echo get_permalink(); ?>"><?php echo get_the_title(); ?></a></h2>
				     					</div>
				     					<div class="slider-date"><?php echo timeago(); ?></div>
				     					<div class="slider-snippet"><?php echo themesapp_excerpt(100); ?></div>
				     				</div>
				     			</div>
								<?php
							}
							wp_reset_postdata();
						endif;
							?>
	     		</div>
	     	</div>
	     </div>
<?php
}
function slidercustomViewMobile($title, $slider1, $slider2, $slider3, $slider4){
	global $post;
	$args1 = array(
		'p' => $slider1,
		'post_type' => 'post',
		'post_status' => 'publish',
	);
	$args2 = array(
		'p' => $slider2,
		'post_type' => 'post',
		'post_status' => 'publish',
	);
	$args3 = array(
		'p' => $slider3,
		'post_type' => 'post',
		'post_status' => 'publish',
	);
	$args4 = array(
		'p' => $slider4,
		'post_type' => 'post',
		'post_status' => 'publish',
	);
	
	$my_query1 = new WP_Query( $args1 );
	$my_query2 = new WP_Query( $args2 );
	$my_query3 = new WP_Query( $args3 );
	$my_query4 = new WP_Query( $args4 );

	if ( $my_query1->have_posts() ): ?>
     <div class="widget slider">
        <?php if(!empty($title)): ?>
	     	<div class="widget-header">
	     		<h3 class="title"><?php echo $title; ?></h3>
	     	</div>
	      <?php endif; ?>
	     	<div class="widget-content">
	     		<div class="slider-box">
							<?php
							while ( $my_query1->have_posts() ) {
								$my_query1->the_post();
								?>
				     			<div class="slider-item">
				     				<div class="slider-image media-image">
				              	<?php echo customthumbnail($post->ID, "image_640_360"); ?>
				     				</div>
				     				<div class="slider-content">
				     					<div class="slider-category"><a href="<?php echo linkcategory(); ?>"><?php echo labelcategory(); ?></a></div>
				     					<div class="slider-title">
				     						<h2><a class="slider-link media-link" href="<?php echo get_permalink(); ?>"><?php echo get_the_title(); ?></a></h2>
				     					</div>
				     					<div class="slider-date"><?php echo timeago(); ?></div>
				     					<div class="slider-snippet"><?php echo themesapp_excerpt(100); ?></div>
				     				</div>
				     			</div>
								<?php
							}
							wp_reset_postdata();
						endif;
							?>
							<?php
						if ( $my_query2->have_posts() ):
							while ( $my_query2->have_posts() ) {
								$my_query2->the_post();
								?>
				     			<div class="slider-item">
				     				<div class="slider-image media-image">
				              	<?php echo customthumbnail($post->ID, "image_640_360"); ?>
				     				</div>
				     				<div class="slider-content">
				     					<div class="slider-category"><a href="<?php echo linkcategory(); ?>"><?php echo labelcategory(); ?></a></div>
				     					<div class="slider-title">
				     						<h2><a class="slider-link media-link" href="<?php echo get_permalink(); ?>"><?php echo get_the_title(); ?></a></h2>
				     					</div>
				     					<div class="slider-date"><?php echo timeago(); ?></div>
				     					<div class="slider-snippet"><?php echo themesapp_excerpt(100); ?></div>
				     				</div>
				     			</div>
								<?php
							}
							wp_reset_postdata();
						endif;
							?>
							<?php
						if ( $my_query3->have_posts() ):
							while ( $my_query3->have_posts() ) {
								$my_query3->the_post();
								?>
				     			<div class="slider-item">
				     				<div class="slider-image media-image">
				              	<?php echo customthumbnail($post->ID, "image_640_360"); ?>
				     				</div>
				     				<div class="slider-content">
				     					<div class="slider-category"><a href="<?php echo linkcategory(); ?>"><?php echo labelcategory(); ?></a></div>
				     					<div class="slider-title">
				     						<h2><a class="slider-link media-link" href="<?php echo get_permalink(); ?>"><?php echo get_the_title(); ?></a></h2>
				     					</div>
				     					<div class="slider-date"><?php echo timeago(); ?></div>
				     					<div class="slider-snippet"><?php echo themesapp_excerpt(100); ?></div>
				     				</div>
				     			</div>
								<?php
							}
							wp_reset_postdata();
						endif;
							?>
							<?php
						if ( $my_query4->have_posts() ):
							while ( $my_query4->have_posts() ) {
								$my_query4->the_post();
								?>
				     			<div class="slider-item">
				     				<div class="slider-image media-image">
				              	<?php echo customthumbnail($post->ID, "image_640_360"); ?>
				     				</div>
				     				<div class="slider-content">
				     					<div class="slider-category"><a href="<?php echo linkcategory(); ?>"><?php echo labelcategory(); ?></a></div>
				     					<div class="slider-title">
				     						<h2><a class="slider-link media-link" href="<?php echo get_permalink(); ?>"><?php echo get_the_title(); ?></a></h2>
				     					</div>
				     					<div class="slider-date"><?php echo timeago(); ?></div>
				     					<div class="slider-snippet"><?php echo themesapp_excerpt(100); ?></div>
				     				</div>
				     			</div>
								<?php
							}
							wp_reset_postdata();
						endif;
							?>
	     		</div>
	     	</div>
	     </div>
<?php
}
class slidercustom extends WP_Widget {

	public function __construct() {
		$idwidget = 'slidercustom';
		$namewidget = '📌 Slider Custom';
		$descwidget = 'Headline besar di beranda yang ditampilkan dalam bentuk slider.';
		parent::__construct($idwidget, $namewidget, array('description'=> $descwidget));
	}
	public function widget( $args, $instance ) {
		if($instance['mobile'] == 'yes'){
			if (function_exists( 'is_amp_endpoint' ) && is_amp_endpoint()) {
				slidercustomViewMobile($instance['title'], $instance['slider1'], $instance['slider2'], $instance['slider3'], $instance['slider4']);
			}elseif (wp_is_mobile()) {
				slidercustomViewMobile($instance['title'], $instance['slider1'], $instance['slider2'], $instance['slider3'], $instance['slider4']);
			}
		}
		if($instance['desktop'] == 'yes'){
			if (function_exists( 'is_amp_endpoint' ) && is_amp_endpoint()) {
			}elseif (wp_is_mobile()) {
			}else{
				slidercustomViewDesktop($instance['title'], $instance['slider1'], $instance['slider2'], $instance['slider3'], $instance['slider4']);
			}
		}
	}
	public function update( $new_instance, $old_instance ) {
		$instance = array();
		if ( ! empty( $new_instance['title'] ) ) {
			$instance['title'] = sanitize_text_field( $new_instance['title'] );
		}
		if ( ! empty( $new_instance['slider1'] ) ) {
			$instance['slider1'] = sanitize_text_field( $new_instance['slider1'] );
		}
		if ( ! empty( $new_instance['slider2'] ) ) {
			$instance['slider2'] = sanitize_text_field( $new_instance['slider2'] );
		}
		if ( ! empty( $new_instance['slider3'] ) ) {
			$instance['slider3'] = sanitize_text_field( $new_instance['slider3'] );
		}
		if ( ! empty( $new_instance['slider4'] ) ) {
			$instance['slider4'] = sanitize_text_field( $new_instance['slider4'] );
		}
		$instance['desktop'] = isset( $new_instance['desktop'] ) ? 'yes' : 'no';
		$instance['mobile'] = isset( $new_instance['mobile'] ) ? 'yes' : 'no';
		return $instance;
	}

	public function form( $instance ) {
		$defaults = array(
			'title' => '',
			'slider1' => '-1',
			'slider2' => '-1',
			'slider3' => '-1',
			'slider4' => '-1',
			'desktop' => 'yes',
			'mobile' => 'yes',
		);
		$instance = wp_parse_args( (array) $instance, $defaults ); 
		?>
		<div class="related-form-controls">
			<p>
				<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:' ); ?></label>
				<input type="text" class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" value="<?php echo $instance['title']; ?>" />
			</p>
			<hr>
			<h3>Pengaturan Slider</h3>
			<?php
		$args = array(
			'post_type' => 'post',
			'post_status' => 'publish',
			'posts_per_page'=> 20
		);
		?>
    <?php $my_posts = get_posts( $args ); ?>
			<p>
				<label for="<?php echo $this->get_field_id( 'slider1' ); ?>"><?php echo 'Slider 1:'; ?></label>
				<select id="<?php echo $this->get_field_id('slider1'); ?>" name="<?php echo $this->get_field_name('slider1'); ?>" class="widefat" style="width:100%;" required>
					<option <?php selected( $instance['slider1'], "-1" ); ?> value="-1">Pilih Artikel</option>
					<?php foreach($my_posts as $my_post) { ?>
						<option <?php selected( $instance['slider1'], $my_post->ID ); ?> value="<?php echo $my_post->ID; ?>"><?php echo $my_post->post_title; ?></option>
					<?php } ?>      
				</select>
			</p>
			<p>
				<label for="<?php echo $this->get_field_id( 'slider2' ); ?>"><?php echo 'Slider 2:'; ?></label>
				<select id="<?php echo $this->get_field_id('slider2'); ?>" name="<?php echo $this->get_field_name('slider2'); ?>" class="widefat" style="width:100%;" required>
					<option <?php selected( $instance['slider2'], "-1" ); ?> value="-1">Pilih Artikel</option>
					<?php foreach($my_posts as $my_post) { ?>
						<option <?php selected( $instance['slider2'], $my_post->ID ); ?> value="<?php echo $my_post->ID; ?>"><?php echo $my_post->post_title; ?></option>
					<?php } ?>      
				</select>
			</p>
			<p>
				<label for="<?php echo $this->get_field_id( 'slider3' ); ?>"><?php echo 'Slider 3:'; ?></label>
				<select id="<?php echo $this->get_field_id('slider3'); ?>" name="<?php echo $this->get_field_name('slider3'); ?>" class="widefat" style="width:100%;" required>
					<option <?php selected( $instance['slider3'], "-1" ); ?> value="-1">Pilih Artikel</option>
					<?php foreach($my_posts as $my_post) { ?>
						<option <?php selected( $instance['slider3'], $my_post->ID ); ?> value="<?php echo $my_post->ID; ?>"><?php echo $my_post->post_title; ?></option>
					<?php } ?>      
				</select>
			</p>
			<p>
				<label for="<?php echo $this->get_field_id( 'slider4' ); ?>"><?php echo 'Slider 4:'; ?></label>
				<select id="<?php echo $this->get_field_id('slider4'); ?>" name="<?php echo $this->get_field_name('slider4'); ?>" class="widefat" style="width:100%;" required>
					<option <?php selected( $instance['slider4'], "-1" ); ?> value="-1">Pilih Artikel</option>
					<?php foreach($my_posts as $my_post) { ?>
						<option <?php selected( $instance['slider4'], $my_post->ID ); ?> value="<?php echo $my_post->ID; ?>"><?php echo $my_post->post_title; ?></option>
					<?php } ?>      
				</select>
			</p>
			<hr>
			<h3>Pengaturan Tampilan</h3>
			<p>
				<input type="checkbox" id="<?php echo $this->get_field_id( 'desktop' ); ?>" name="<?php echo $this->get_field_name( 'desktop' ); ?>" value="yes"<?php checked( 'yes', $instance['desktop'] ); ?>>
				<label for="<?php echo $this->get_field_id( 'desktop' ); ?>">Tampilkan dalam versi desktop</label><br>

				<input type="checkbox" id="<?php echo $this->get_field_id( 'mobile' ); ?>" name="<?php echo $this->get_field_name( 'mobile' ); ?>" value="yes"<?php checked( 'yes', $instance['mobile'] ); ?>>
				<label for="<?php echo $this->get_field_id( 'mobile' ); ?>">Tampilkan dalam versi mobile</label>
			</p>
		</div>
		<?php
	}
}

function slidercustomload() {
	register_widget( 'slidercustom' );
}
add_action( 'widgets_init', 'slidercustomload' );