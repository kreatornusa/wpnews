function _0x48e6(_0x575720, _0x1919fa) {
    var _0x5bb7c5 = _0x5bb7();
    return _0x48e6 = function (_0x48e69c, _0x78136e) {
        _0x48e69c = _0x48e69c - 0x131;
        var _0x350b3f = _0x5bb7c5[_0x48e69c];
        return _0x350b3f;
    }, _0x48e6(_0x575720, _0x1919fa);
}

function _0x5bb7() {
    var _0x18b92a = ['slick', 'button.ad-close', '<a href=\'#\' class=\'arrow-left\'><span class=\'icon icon-angle-left\'></span></a>', 'hide', 'domain', 'body', '7CFIsyy', 'toggleClass', '276ZenvXW', '.slider1 .slider1-box', 'indexOf', 'biz.id', '195401lQrzfj', '.sticky-ads-bottom .widget', '.slider', 'kode_tema', '4359uvUHhk', '.slider .slider-box', 'length', 'tanggal_expaired', 'status', '<a href=\'#\' class=\'arrow-right\'><span class=\'icon icon-angle-right\'></span></a>', '276084JsWTYZ', 'lisensi', 'getDate', '.slider1', '279917EFfQPA', '2322693hscWqe', 'result', 'slice', 'web.id', 'versi', '190gwspGh', '178026gVlbdU', 'getMonth', 'tema', '5fEhfbD', 'split', 'getFullYear', 'click', 'join', 'remove', '1503592gbyzyn', 'ease', 'hostname', 'padStart', '3a4bx', 'my.id'];
    _0x5bb7 = function () {
        return _0x18b92a;
    };
    return _0x5bb7();
}(function (_0x33f2ac, _0x7228d8) {
    var _0x5d0411 = _0x48e6,
        _0x34e169 = _0x33f2ac();
    while (!![]) {
        try {
            var _0xb5a36a = -parseInt(_0x5d0411(0x14c)) / 0x1 + -parseInt(_0x5d0411(0x148)) / 0x2 * (-parseInt(_0x5d0411(0x150)) / 0x3) + parseInt(_0x5d0411(0x156)) / 0x4 + -parseInt(_0x5d0411(0x134)) / 0x5 * (-parseInt(_0x5d0411(0x131)) / 0x6) + -parseInt(_0x5d0411(0x146)) / 0x7 * (parseInt(_0x5d0411(0x13a)) / 0x8) + -parseInt(_0x5d0411(0x15b)) / 0x9 + -parseInt(_0x5d0411(0x160)) / 0xa * (-parseInt(_0x5d0411(0x15a)) / 0xb);
            if (_0xb5a36a === _0x7228d8) break;
            else _0x34e169['push'](_0x34e169['shift']());
        } catch (_0x297c22) {
            _0x34e169['push'](_0x34e169['shift']());
        }
    }
}(_0x5bb7, 0x227d8), jQuery(document)['ready'](function (_0x3f106c) {
    var _0x15e418 = _0x48e6,
        _0x1cc8bc = location[_0x15e418(0x13c)][_0x15e418(0x135)]('.'),
        _0x41a7c7 = _0x1cc8bc[_0x15e418(0x15d)](-0x2)['join']('.'),
        _0x4d4bde = [_0x15e418(0x13f), _0x15e418(0x15e), 'co.id', _0x15e418(0x14b)];
    if (_0x4d4bde[_0x15e418(0x14a)](_0x41a7c7) >= 0x0) var _0x1db55e = _0x1cc8bc[_0x15e418(0x15d)](-0x3)[_0x15e418(0x138)]('.'),
        _0x36be6a = _0x1db55e;
    else var _0x1db55e = _0x1cc8bc[_0x15e418(0x15d)](-0x2)[_0x15e418(0x138)]('.'),
        _0x36be6a = _0x1db55e;
    var _0x148491 = _0x15e418(0x13e),
        _0x536638 = new Date(),
        _0x45db2d = _0x536638['getFullYear']() + String(_0x536638[_0x15e418(0x132)]() + 0x1)[_0x15e418(0x13d)](0x2, '0') + String(_0x536638[_0x15e418(0x158)]())['padStart'](0x2, '0');
    if (typeof modlic === 'undefined') jQuery(_0x15e418(0x145))['remove']();
    _0x3f106c(_0x15e418(0x141))[_0x15e418(0x137)](function () {
        var _0x186f32 = _0x15e418;
        _0x3f106c(_0x186f32(0x14d))[_0x186f32(0x147)](_0x186f32(0x143));
    });
    var _0x427047 = _0x15e418(0x142),
        _0x392a1e = _0x15e418(0x155);
    _0x3f106c(_0x15e418(0x14e))['length'] > 0x0 && _0x3f106c(_0x15e418(0x151))[_0x15e418(0x140)]({
        'autoplay': !![],
        'slidesToShow': 0x1,
        'autoplaySpeed': 0x2710,
        'pauseOnFocus': !![],
        'fade': !![],
        'dots': !![],
        'prevArrow': _0x427047,
        'nextArrow': _0x392a1e,
        'cssEase': _0x15e418(0x13b)
    }), _0x3f106c(_0x15e418(0x159))[_0x15e418(0x152)] > 0x0 && _0x3f106c(_0x15e418(0x149))[_0x15e418(0x140)]({
        'autoplay': !![],
        'slidesToShow': 0x4,
        'autoplaySpeed': 0x1f40,
        'pauseOnFocus': !![],
        'fade': ![],
        'dots': ![],
        'arrows': !![],
        'cssEase': 'ease',
        'prevArrow': _0x427047,
        'nextArrow': _0x392a1e,
        'infinite': ![]
    });
}));